package com.campus.gpuscheduler.exception;

/** Thrown when a GPU cannot be allocated or released (e.g. not available). */
public class AllocationException extends RuntimeException {
    public AllocationException(String message) { super(message); }
    public AllocationException(String message, Throwable cause) { super(message, cause); }
}
