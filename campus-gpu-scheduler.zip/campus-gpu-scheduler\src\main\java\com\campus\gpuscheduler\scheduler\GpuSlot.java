package com.campus.gpuscheduler.scheduler;

/**
 * Snapshot of one GPU for wait estimation.
 * busyForMinutes = simulated minutes until the running job (if any) releases it; 0 when free.
 */
public record GpuSlot(int gpuId, int vramGb, boolean inMaintenance, double busyForMinutes) {
    /** Bean-style getter so templates can read gpuId. */
    public int getGpuId() { return gpuId; }
    /** Bean-style getter so templates can read vramGb. */
    public int getVramGb() { return vramGb; }
    /** Bean-style getter so templates can read inMaintenance. */
    public boolean getInMaintenance() { return inMaintenance; }
    /** Bean-style getter so templates can read busyForMinutes. */
    public double getBusyForMinutes() { return busyForMinutes; }
 }
