package com.campus.gpuscheduler.model;

/** Kind of compute workload. The default VRAM is only a suggestion shown on the submit form. */
public enum WorkloadType {
    TRAINING("Model training", 16),
    FINE_TUNING("Fine-tuning", 24),
    INFERENCE("Batch inference", 8),
    NOTEBOOK("Notebook experiment", 4),
    RENDERING("Rendering / simulation", 12);

    private final String label;
    private final int defaultVramGb;

    WorkloadType(String label, int defaultVramGb) {
        this.label = label;
        this.defaultVramGb = defaultVramGb;
    }

    public String getLabel() { return label; }
    public int getDefaultVramGb() { return defaultVramGb; }
}
