package com.campus.gpuscheduler.model;

import com.campus.gpuscheduler.exception.AllocationException;

/** A simulated GPU node. Allocation is exclusive: one job owns the whole GPU. */
public class GpuResource {
    private final int gpuId;
    private final String gpuName;
    private final String gpuType;
    private final int vramGb;
    private final int cores;
    private GpuStatus status;

    public GpuResource(int gpuId, String gpuName, String gpuType, int vramGb, int cores, GpuStatus status) {
        this.gpuId = gpuId;
        this.gpuName = gpuName;
        this.gpuType = gpuType;
        this.vramGb = vramGb;
        this.cores = cores;
        this.status = status;
    }

    public boolean isAvailable() { return status == GpuStatus.AVAILABLE; }

    /** AVAILABLE -> BUSY. Throws if the GPU cannot be allocated. */
    public void allocate() {
        if (!isAvailable()) throw new AllocationException(gpuName + " is not available (" + status + ")");
        status = GpuStatus.BUSY;
    }

    /** BUSY -> AVAILABLE. A GPU in MAINTENANCE stays in maintenance. */
    public void release() {
        if (status == GpuStatus.BUSY) status = GpuStatus.AVAILABLE;
    }

    public int getGpuId() { return gpuId; }
    public String getGpuName() { return gpuName; }
    public String getGpuType() { return gpuType; }
    public int getVramGb() { return vramGb; }
    public int getCores() { return cores; }
    public GpuStatus getStatus() { return status; }
}
