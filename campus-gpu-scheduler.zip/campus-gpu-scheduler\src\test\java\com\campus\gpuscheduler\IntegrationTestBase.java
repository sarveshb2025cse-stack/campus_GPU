package com.campus.gpuscheduler;

import com.campus.gpuscheduler.model.SessionUser;
import com.campus.gpuscheduler.model.Role;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;

/** Boots the real app against an in-memory H2 database (MySQL mode) with a controllable clock. */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("h2")
@Import(IntegrationTestBase.TestClockConfig.class)
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:testdb;MODE=MySQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1",
        "scheduler.auto-tick-enabled=false",
        "sim.seconds-per-minute=1"})
public abstract class IntegrationTestBase {

    /** A clock tests can move forward to "fast-forward" the simulated job run time. */
    public static class MutableClock extends Clock {
        private Instant now = Instant.parse("2026-11-04T10:00:00Z");
        private final ZoneId zone = ZoneId.of("UTC");
        public void advance(Duration d) { now = now.plus(d); }
        public void reset() { now = Instant.parse("2026-11-04T10:00:00Z"); }
        @Override public ZoneId getZone() { return zone; }
        @Override public Clock withZone(ZoneId z) { return this; }
        @Override public Instant instant() { return now; }
    }

    @TestConfiguration
    static class TestClockConfig {
        @Bean @Primary MutableClock testClock() { return new MutableClock(); }
    }

    @Autowired protected JdbcTemplate jdbc;
    @Autowired protected MutableClock clock;

    /** Clears job data between tests (test database only) and frees all GPUs. */
    @BeforeEach
    void resetDatabase() {
        jdbc.update("DELETE FROM job_status_history");
        jdbc.update("DELETE FROM resource_allocations");
        jdbc.update("DELETE FROM jobs");
        jdbc.update("UPDATE gpu_resources SET status = 'AVAILABLE'");
        jdbc.update("UPDATE scheduler_settings SET setting_value = 'FCFS' WHERE setting_key = 'scheduling_policy'");
        clock.reset();
    }

    protected SessionUser user(String username) {
        return jdbc.queryForObject("SELECT user_id, username, full_name, role FROM users WHERE username = ?",
                (rs, i) -> new SessionUser(rs.getInt(1), rs.getString(2), rs.getString(3), Role.valueOf(rs.getString(4))),
                username);
    }

    /** COUNT(*) helper that returns a primitive int (avoids assertEquals(int, Integer) ambiguity). */
    protected int count(String sql, Object... args) {
        Integer n = jdbc.queryForObject(sql, Integer.class, args);
        return n == null ? 0 : n;
    }

    protected void advanceSeconds(long s) { clock.advance(Duration.ofSeconds(s)); }
}
