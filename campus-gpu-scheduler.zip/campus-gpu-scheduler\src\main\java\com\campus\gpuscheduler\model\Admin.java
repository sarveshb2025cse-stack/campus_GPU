package com.campus.gpuscheduler.model;

public class Admin extends User {
    public Admin(int id, String username, String fullName, String email) { super(id, username, fullName, email); }
    @Override public Role getRole() { return Role.ADMIN; }
    @Override public int getMaxActiveJobs() { return 10; }
    @Override public int getMaxRunningJobs() { return 4; }
    @Override public int getMaxPriority() { return 5; }
}
