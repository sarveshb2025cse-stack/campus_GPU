package com.campus.gpuscheduler.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Inserts demo users, simulated GPUs and default settings ONLY when the tables are empty.
 * It never updates or deletes existing rows, so restarting the app keeps all data.
 */
@Component
public class DataSeeder implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    private final JdbcTemplate jdbc;
    private final PasswordEncoder encoder;

    public DataSeeder(JdbcTemplate jdbc, PasswordEncoder encoder) {
        this.jdbc = jdbc;
        this.encoder = encoder;
    }

    @Override
    public void run(String... args) {
        if (count("users") == 0) {
            user("admin", "Campus Admin", "admin@campus.local", "admin123", "ADMIN");
            user("faculty1", "Dr. Parthasarathy", "parthasarathy@campus.local", "faculty123", "FACULTY");
            user("student1", "Sarvesh B", "sarvesh@campus.local", "student123", "STUDENT");
            user("student2", "Jatin Dhave", "jatin@campus.local", "student123", "STUDENT");
            user("student3", "Sakthi Sridhar B", "sakthi@campus.local", "student123", "STUDENT");
            user("student4", "Sreedevi Prasad", "sreedevi@campus.local", "student123", "STUDENT");
            log.info("Seeded demo users");
        }
        if (count("gpu_resources") == 0) {
            gpu("GPU-01", "Simulated RTX 4090", 24, 16384);
            gpu("GPU-02", "Simulated RTX 4090", 24, 16384);
            gpu("GPU-03", "Simulated A100", 40, 6912);
            gpu("GPU-04", "Simulated A100", 80, 6912);
            log.info("Seeded simulated GPU nodes");
        }
        setting("scheduling_policy", "FCFS");
        setting("auto_tick", "ON");
    }

    private int count(String table) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM " + table, Integer.class);
        return n == null ? 0 : n;
    }

    private void user(String username, String fullName, String email, String password, String role) {
        jdbc.update("INSERT INTO users (username, full_name, email, password_hash, role) VALUES (?,?,?,?,?)",
                username, fullName, email, encoder.encode(password), role);
    }

    private void gpu(String name, String type, int vram, int cores) {
        jdbc.update("INSERT INTO gpu_resources (gpu_name, gpu_type, vram_gb, cores, status) VALUES (?,?,?,?,'AVAILABLE')",
                name, type, vram, cores);
    }

    /** Inserts the default only if the key does not exist yet (keeps admin changes). */
    private void setting(String key, String value) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM scheduler_settings WHERE setting_key = ?", Integer.class, key);
        if (n == null || n == 0) {
            jdbc.update("INSERT INTO scheduler_settings (setting_key, setting_value) VALUES (?,?)", key, value);
        }
    }
}
