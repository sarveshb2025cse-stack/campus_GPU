# Demo guide (≈ 8 minutes)

Start the app (see README), open <http://localhost:8080>. All GPU work is simulated; say so in the first minute.

## Before you start
1. Log in as **admin / admin123** → **Scheduler** → click **Turn automatic ticks OFF** (so you control each step).
2. Policy **FCFS** selected → **Save policy**.

## Script
| # | Who | Do | Expect |
|---|---|---|---|
| 1 | admin | **Dashboard** | 4 GPUs, 168 GB VRAM, 4 available, 0 queued, simulated telemetry |
| 2 | admin | **GPU Resources** | 4 nodes; green banner "status matches allocation records" |
| 3 | admin | **Scheduler** → select FCFS → Save | "Scheduling policy set to FCFS" |
| 4 | admin | Log out | Login page |
| 5 | student1 / student123 | **Submit Job**: name `Demo ResNet`, workload *Model training*, 1 GPU, VRAM auto-fills 16, 2 minutes, priority 2 | Redirect to queue with success message |
| 6 | student1 | Try an invalid submit (empty name, VRAM 100) | Field error messages, nothing saved |
| 7 | student1 | **Job Queue** | Job at position 1, est. wait "next tick" |
| 8 | student1 | Open `/admin/settings` | 403 page (role check) |
| 9 | student1 | Log out, log in as admin | |
| 10 | admin | **Scheduler** → **Run scheduler tick now** | Message: job started on GPU-01 (or a 24 GB GPU) |
| 11 | admin | **Job Queue** | Job under *Running* with a progress bar; **Dashboard**: 1 busy GPU, 1 running |
| 12 | admin | Wait ≈ 6 s (2 min × 3 s) and **Run tick** again | "1 completed" |
| 13 | admin | **Dashboard / GPU Resources** | GPU back to AVAILABLE; job in *Recently finished* |
| 14 | admin | Open the job → **Status history** | QUEUED → RUNNING → COMPLETED with times; allocation shows released time |

## Extra demos
- **Priority vs FCFS**: as faculty1 (priority up to 5) submit two 4-GPU jobs (priority 1 then 5). Under FCFS the first runs; switch to PRIORITY *before* ticking and the second runs first.
- **Exclusive allocation / all-or-nothing**: submit a 3-GPU job and a 2-GPU job; after a tick the 2-GPU job stays queued and has no allocation rows.
- **Failure handling**: Scheduler → *Simulate failure* on a running job → FAILED, GPUs released.
- **Maintenance**: Scheduler → *Set maintenance* on a free GPU → it is excluded from allocation and dashboard utilization.
- **Fair use**: student1 may have 3 queued/running jobs and run 1 at a time.
- **Reports** (faculty/admin): usage per user and per GPU.

## Talking points for viva
Encapsulation (private fields + getters), Inheritance (`User` → Student/Faculty/Admin), Abstraction (`SchedulingPolicy`, abstract `User`),
Polymorphism (policy swap at runtime, per-role limits), exceptions (`JobValidationException`, `AllocationException`, …),
JdbcTemplate + PreparedStatements, JOINs, transactions with savepoints, PK/FK and the `active_gpu_lock` constraint.
