# Database design

Schema files: `src/main/resources/schema-mysql.sql` (MySQL 8) and `schema-h2.sql` (H2 in MySQL mode, used for tests/demo).
Both run at startup and use only `CREATE TABLE IF NOT EXISTS`, so restarting never loses data.
Seed data (users, 4 simulated GPUs, settings) is inserted by `DataSeeder` only when the table is empty.

![ER diagram](docs/diagrams/er.png)

## Tables
| Table | Purpose | Key columns |
|---|---|---|
| `users` | Accounts | `user_id` PK, `username` UNIQUE, `email` UNIQUE, `password_hash` (BCrypt), `role` CHECK in STUDENT/FACULTY/ADMIN |
| `gpu_resources` | Simulated GPU nodes | `gpu_id` PK, `gpu_name` UNIQUE, `vram_gb`, `cores`, `status` CHECK in AVAILABLE/BUSY/MAINTENANCE |
| `jobs` | Compute job requests | `job_id` PK, `user_id` FK→users, `gpu_count`, `vram_gb`, `duration_min`, `priority` CHECK 1–5, `status` CHECK, `submitted_at`, `started_at`, `finished_at` |
| `resource_allocations` | Which job holds which GPU, and when | `allocation_id` PK, `job_id` FK→jobs, `gpu_id` FK→gpu_resources, `allocated_at`, `released_at`, `active_gpu_lock` (generated) UNIQUE |
| `job_status_history` | Every status change | `history_id` PK, `job_id` FK→jobs, `old_status`, `new_status`, `changed_at`, `note` |
| `scheduler_settings` | Admin settings | `setting_key` PK (`scheduling_policy`, `auto_tick`), `setting_value` |

`scheduler_settings` and the extra columns `username`, `password_hash`, `cores`, `workload_type`, `vram_gb`,
`duration_min`, `started_at`, `finished_at`, `note` go beyond the proposal's ER sketch; they are needed for login, scheduling and history.

## Relationships (all 1 : N)
User → Jobs · Job → History · Job → Allocations · GPU → Allocations (one GPU is allocated to many jobs over time).

## Exclusive GPU allocation
```sql
active_gpu_lock INT GENERATED ALWAYS AS (CASE WHEN released_at IS NULL THEN gpu_id ELSE NULL END) STORED,
CONSTRAINT uq_active_gpu UNIQUE (active_gpu_lock)
```
While an allocation is active the generated column equals `gpu_id`; when `released_at` is set it becomes NULL.
UNIQUE ignores NULLs, so a GPU can have *many* released rows but only *one* active row. Even if application code had a bug,
the database would reject a second active allocation of the same GPU.

## Transactions
- `SchedulerService.tick()` runs in one transaction. Each job start (allocate all GPUs + mark RUNNING) runs in a nested
  transaction (JDBC savepoint): if any step fails, everything for that job rolls back and the other jobs are unaffected.
- `GpuRepository.findFreeCompatibleForUpdate` uses `SELECT … FOR UPDATE` so two ticks cannot pick the same GPU.
- `JobRepository.updateStatus` is a compare-and-set (`WHERE job_id=? AND status=?`), so two actors cannot both move a job.
- Submitting a job, changing status (+history, +release) and cancelling are each one transaction.

## SQL used (examples)
```sql
-- queue ordering (policy)           FCFS: ORDER BY submitted_at, job_id
SELECT * FROM jobs WHERE status='QUEUED' ORDER BY priority DESC, submitted_at ASC;   -- PRIORITY (also done in Java)

-- GPU inventory with the job holding each GPU (LEFT JOIN)
SELECT g.*, j.job_id, j.job_name FROM gpu_resources g
LEFT JOIN resource_allocations a ON a.gpu_id=g.gpu_id AND a.released_at IS NULL
LEFT JOIN jobs j ON j.job_id=a.job_id;

-- usage per user (JOIN + GROUP BY + aggregates)
SELECT u.full_name, COUNT(j.job_id), SUM(CASE WHEN j.status='COMPLETED' THEN j.duration_min*j.gpu_count ELSE 0 END)
FROM users u LEFT JOIN jobs j ON j.user_id=u.user_id GROUP BY u.user_id, u.full_name;
```
All SQL uses bound parameters (`?`) through `JdbcTemplate`; no user input is concatenated into SQL.

## Consistency check
`GpuRepository.countInconsistent()` counts GPUs whose `status` disagrees with `resource_allocations`
(BUSY without an active allocation, or not-BUSY with one). It is shown on the GPU page and must be 0.

## Safety
No script drops tables or deletes rows. The only `DELETE` statements are in the automated tests and run against an
in-memory H2 test database.
