package com.campus.gpuscheduler.scheduler;

import com.campus.gpuscheduler.model.GpuResource;
import com.campus.gpuscheduler.model.GpuStatus;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

/** Simulated temperature / power / utilization. These numbers are generated, not measured. */
public record Telemetry(int tempC, int powerW, int utilPct) {
    /** Bean-style getter so templates can read tempC. */
    public int getTempC() { return tempC; }
    /** Bean-style getter so templates can read powerW. */
    public int getPowerW() { return powerW; }
    /** Bean-style getter so templates can read utilPct. */
    public int getUtilPct() { return utilPct; }


    public static Telemetry simulate(GpuResource gpu, boolean busy, LocalDateTime now) {
        if (gpu.getStatus() == GpuStatus.MAINTENANCE) return new Telemetry(27, 0, 0);
        double wave = Math.sin(now.toEpochSecond(ZoneOffset.UTC) / 7.0 + gpu.getGpuId() * 1.7);
        if (busy) {
            return new Telemetry((int) Math.round(72 + wave * 8), (int) Math.round(290 + wave * 40),
                    (int) Math.round(88 + wave * 10));
        }
        return new Telemetry((int) Math.round(34 + wave * 2), (int) Math.round(28 + wave * 3),
                (int) Math.round(1 + wave));
    }
}
