package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.model.SessionUser;
import jakarta.servlet.http.HttpSession;

import java.security.SecureRandom;
import java.util.HexFormat;

/** Small helpers for what we keep in the HTTP session. */
public final class Sessions {
    public static final String USER = "currentUser";
    public static final String CSRF = "csrfToken";
    private static final SecureRandom RANDOM = new SecureRandom();

    private Sessions() { }

    public static SessionUser user(HttpSession session) {
        return session == null ? null : (SessionUser) session.getAttribute(USER);
    }

    /** Returns this session's CSRF token, creating it on first use. */
    public static String csrf(HttpSession session) {
        Object existing = session.getAttribute(CSRF);
        if (existing != null) return existing.toString();
        byte[] bytes = new byte[24];
        RANDOM.nextBytes(bytes);
        String token = HexFormat.of().formatHex(bytes);
        session.setAttribute(CSRF, token);
        return token;
    }
}
