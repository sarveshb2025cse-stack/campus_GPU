package com.campus.gpuscheduler.scheduler;

import com.campus.gpuscheduler.model.ComputeJob;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Approximate wait-time estimator (simulated minutes).
 * Walks the queue in scheduling order and "pretends" each job starts on the earliest-free
 * compatible GPUs. A job that can never fit gets no estimate (null).
 * Simplified: it ignores per-user running limits and future submissions.
 */
public class QueueEstimator {
    public static final int DEFAULT_AVERAGE_MIN = 30;

    /** Average of recent completed durations, or the default when there is no history yet. */
    public int averageDuration(Collection<Integer> recentDurations) {
        if (recentDurations == null || recentDurations.isEmpty()) return DEFAULT_AVERAGE_MIN;
        return (int) Math.round(recentDurations.stream().mapToInt(Integer::intValue).average().orElse(DEFAULT_AVERAGE_MIN));
    }

    /** @return jobId -> estimated wait in whole minutes (null if the job can never fit). */
    public Map<Integer, Integer> estimateAll(List<ComputeJob> orderedQueue, List<GpuSlot> gpus) {
        List<double[]> free = new ArrayList<>();   // {gpuId, vramGb, freeAtMinute}
        for (GpuSlot g : gpus) {
            if (!g.inMaintenance()) free.add(new double[]{g.gpuId(), g.vramGb(), g.busyForMinutes()});
        }
        Map<Integer, Integer> result = new HashMap<>();
        for (ComputeJob job : orderedQueue) {
            List<double[]> compatible = new ArrayList<>(free.stream().filter(s -> s[1] >= job.getVramGb()).toList());
            if (compatible.size() < job.getGpuCount()) {
                result.put(job.getJobId(), null);
                continue;
            }
            compatible.sort(Comparator.comparingDouble((double[] s) -> s[2]).thenComparingDouble(s -> s[0]));
            List<double[]> chosen = compatible.subList(0, job.getGpuCount());
            double start = chosen.stream().mapToDouble(s -> s[2]).max().orElse(0);
            for (double[] s : chosen) s[2] = start + job.getDurationMin();
            result.put(job.getJobId(), (int) Math.ceil(start));
        }
        return result;
    }
}
