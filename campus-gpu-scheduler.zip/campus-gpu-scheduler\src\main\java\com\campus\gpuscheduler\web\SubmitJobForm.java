package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.model.WorkloadType;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/** Form-backing object for Submit Job. Wrapper types so that an empty field gives a friendly error. */
public class SubmitJobForm {
    @NotBlank(message = "Job name is required")
    @Size(max = 100, message = "Job name must be at most 100 characters")
    private String jobName;

    @NotNull(message = "Select a workload type")
    private WorkloadType workloadType;

    @NotNull(message = "Enter the number of GPUs")
    @Min(value = 1, message = "At least 1 GPU")
    @Max(value = 8, message = "At most 8 GPUs")
    private Integer gpuCount = 1;

    @NotNull(message = "Enter the VRAM needed per GPU")
    @Min(value = 1, message = "VRAM must be at least 1 GB")
    @Max(value = 80, message = "VRAM must be at most 80 GB")
    private Integer vramGb;

    @NotNull(message = "Enter the estimated duration")
    @Min(value = 1, message = "Duration must be at least 1 minute")
    @Max(value = 1440, message = "Duration must be at most 1440 minutes (24 h)")
    private Integer durationMin;

    @NotNull(message = "Select a priority")
    @Min(value = 1, message = "Priority must be 1-5")
    @Max(value = 5, message = "Priority must be 1-5")
    private Integer priority = 1;

    public String getJobName() { return jobName; }
    public void setJobName(String jobName) { this.jobName = jobName == null ? null : jobName.trim(); }
    public WorkloadType getWorkloadType() { return workloadType; }
    public void setWorkloadType(WorkloadType workloadType) { this.workloadType = workloadType; }
    public Integer getGpuCount() { return gpuCount; }
    public void setGpuCount(Integer gpuCount) { this.gpuCount = gpuCount; }
    public Integer getVramGb() { return vramGb; }
    public void setVramGb(Integer vramGb) { this.vramGb = vramGb; }
    public Integer getDurationMin() { return durationMin; }
    public void setDurationMin(Integer durationMin) { this.durationMin = durationMin; }
    public Integer getPriority() { return priority; }
    public void setPriority(Integer priority) { this.priority = priority; }
}
