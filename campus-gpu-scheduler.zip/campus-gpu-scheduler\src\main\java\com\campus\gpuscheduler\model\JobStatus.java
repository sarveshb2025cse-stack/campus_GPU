package com.campus.gpuscheduler.model;

/** Job life-cycle. Allowed moves: QUEUED -> RUNNING|CANCELLED, RUNNING -> COMPLETED|FAILED|CANCELLED. */
public enum JobStatus {
    QUEUED, RUNNING, COMPLETED, FAILED, CANCELLED;

    public boolean canTransitionTo(JobStatus next) {
        return switch (this) {
            case QUEUED -> next == RUNNING || next == CANCELLED;
            case RUNNING -> next == COMPLETED || next == FAILED || next == CANCELLED;
            default -> false;
        };
    }

    public boolean isTerminal() { return this == COMPLETED || this == FAILED || this == CANCELLED; }
}
