package com.campus.gpuscheduler.service;

import com.campus.gpuscheduler.model.SessionUser;
import com.campus.gpuscheduler.model.User;
import com.campus.gpuscheduler.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {
    private final UserRepository users;
    private final PasswordEncoder encoder;

    public AuthService(UserRepository users, PasswordEncoder encoder) {
        this.users = users;
        this.encoder = encoder;
    }

    /** Returns the session user if the username exists and the BCrypt hash matches. */
    public Optional<SessionUser> authenticate(String username, String password) {
        if (username == null || password == null) return Optional.empty();
        return users.findCredential(username.trim())
                .filter(c -> encoder.matches(password, c.passwordHash()))
                .map(c -> {
                    User u = c.user();
                    return new SessionUser(u.getUserId(), u.getUsername(), u.getFullName(), u.getRole());
                });
    }
}
