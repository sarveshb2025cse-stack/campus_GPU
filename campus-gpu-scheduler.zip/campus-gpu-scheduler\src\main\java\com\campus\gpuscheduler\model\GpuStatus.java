package com.campus.gpuscheduler.model;

public enum GpuStatus { AVAILABLE, BUSY, MAINTENANCE }
