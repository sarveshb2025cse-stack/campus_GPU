package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.service.DashboardService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {
    private final DashboardService dashboard;

    public DashboardController(DashboardService dashboard) { this.dashboard = dashboard; }

    @GetMapping("/dashboard")
    public String show(Model model) {
        model.addAttribute("d", dashboard.build());
        model.addAttribute("active", "dashboard");
        model.addAttribute("refresh", true);
        return "dashboard";
    }
}
