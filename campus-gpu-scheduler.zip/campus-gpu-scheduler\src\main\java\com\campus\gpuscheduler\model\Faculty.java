package com.campus.gpuscheduler.model;

public class Faculty extends User {
    public Faculty(int id, String username, String fullName, String email) { super(id, username, fullName, email); }
    @Override public Role getRole() { return Role.FACULTY; }
    @Override public int getMaxActiveJobs() { return 6; }
    @Override public int getMaxRunningJobs() { return 2; }
    @Override public int getMaxPriority() { return 5; }
}
