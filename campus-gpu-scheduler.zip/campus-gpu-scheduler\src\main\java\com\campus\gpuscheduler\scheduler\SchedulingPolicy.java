package com.campus.gpuscheduler.scheduler;

import com.campus.gpuscheduler.model.ComputeJob;

import java.util.List;
import java.util.Optional;

/** Strategy interface: how queued jobs are ordered. The Scheduler only talks to this contract. */
public interface SchedulingPolicy {
    /** Name stored in the settings table (FCFS or PRIORITY). */
    String name();

    /** Returns a new list with the candidate jobs in the order they should be considered. */
    List<ComputeJob> order(List<ComputeJob> queued);

    /** The job this policy would consider first, if any. */
    default Optional<ComputeJob> selectNext(List<ComputeJob> queued) {
        return order(queued).stream().findFirst();
    }
}
