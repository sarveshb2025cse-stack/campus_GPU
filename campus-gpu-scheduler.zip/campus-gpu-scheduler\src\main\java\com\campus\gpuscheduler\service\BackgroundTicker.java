package com.campus.gpuscheduler.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/** Runs the scheduler tick periodically while the admin has auto-tick ON. */
@Component
public class BackgroundTicker {
    private static final Logger log = LoggerFactory.getLogger(BackgroundTicker.class);

    private final SchedulerService scheduler;
    private final SettingsService settings;
    private final boolean enabled;

    public BackgroundTicker(SchedulerService scheduler, SettingsService settings,
                            @Value("${scheduler.auto-tick-enabled:true}") boolean enabled) {
        this.scheduler = scheduler;
        this.settings = settings;
        this.enabled = enabled;
    }

    @Scheduled(fixedDelayString = "${scheduler.auto-tick-interval-ms:3000}", initialDelay = 5000)
    public void autoTick() {
        if (!enabled) return;
        try {
            if (settings.isAutoTickOn()) scheduler.tick();
        } catch (RuntimeException e) {
            log.warn("Background tick failed: {}", e.getMessage());
        }
    }
}
