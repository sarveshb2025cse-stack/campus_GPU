package com.campus.gpuscheduler.repository;

import com.campus.gpuscheduler.model.Role;
import com.campus.gpuscheduler.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UserRepository {
    /** A user together with the stored BCrypt hash (only used at login). */
    public record Credential(User user, String passwordHash) {
    /** Bean-style getter so templates can read user. */
    public User getUser() { return user; }
    /** Bean-style getter so templates can read passwordHash. */
    public String getPasswordHash() { return passwordHash; }
 }

    private final JdbcTemplate jdbc;

    private static final RowMapper<User> MAPPER = (rs, i) -> User.create(
            Role.valueOf(rs.getString("role")), rs.getInt("user_id"), rs.getString("username"),
            rs.getString("full_name"), rs.getString("email"));

    public UserRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public Optional<User> findById(int id) {
        return jdbc.query("SELECT * FROM users WHERE user_id = ?", MAPPER, id).stream().findFirst();
    }

    public Optional<Credential> findCredential(String username) {
        return jdbc.query("SELECT * FROM users WHERE username = ?",
                (rs, i) -> new Credential(MAPPER.mapRow(rs, i), rs.getString("password_hash")), username)
                .stream().findFirst();
    }

    public List<User> findAll() {
        return jdbc.query("SELECT * FROM users ORDER BY user_id", MAPPER);
    }

    public int count() {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM users", Integer.class);
        return n == null ? 0 : n;
    }
}
