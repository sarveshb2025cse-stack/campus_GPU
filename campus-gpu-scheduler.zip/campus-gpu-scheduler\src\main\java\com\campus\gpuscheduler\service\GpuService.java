package com.campus.gpuscheduler.service;

import com.campus.gpuscheduler.exception.NotFoundException;
import com.campus.gpuscheduler.model.GpuResource;
import com.campus.gpuscheduler.model.GpuStatus;
import com.campus.gpuscheduler.repository.GpuRepository;
import com.campus.gpuscheduler.scheduler.Telemetry;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class GpuService {
    /** What the GPU pages show: DB row + holder job + simulated telemetry. */
    public record GpuView(GpuResource gpu, Integer activeJobId, String activeJobName, Telemetry telemetry) {
    /** Bean-style getter so templates can read gpu. */
    public GpuResource getGpu() { return gpu; }
    /** Bean-style getter so templates can read activeJobId. */
    public Integer getActiveJobId() { return activeJobId; }
    /** Bean-style getter so templates can read activeJobName. */
    public String getActiveJobName() { return activeJobName; }
    /** Bean-style getter so templates can read telemetry. */
    public Telemetry getTelemetry() { return telemetry; }
 }

    private final GpuRepository gpus;
    private final SimSettings sim;

    public GpuService(GpuRepository gpus, SimSettings sim) {
        this.gpus = gpus;
        this.sim = sim;
    }

    public List<GpuView> views() {
        LocalDateTime now = sim.now();
        return gpus.findAllWithActiveJob().stream()
                .map(r -> new GpuView(r.gpu(), r.activeJobId(), r.activeJobName(),
                        Telemetry.simulate(r.gpu(), r.activeJobId() != null, now)))
                .toList();
    }

    /** Admin: take a free GPU out of service, or put it back. A busy GPU cannot be switched. */
    @Transactional
    public void setMaintenance(int gpuId, boolean maintenance) {
        GpuResource gpu = gpus.findById(gpuId).orElseThrow(() -> new NotFoundException("GPU not found"));
        if (maintenance) {
            if (gpu.getStatus() == GpuStatus.BUSY) {
                throw new IllegalStateException(gpu.getGpuName() + " is running a job; wait or cancel the job first");
            }
            gpus.updateStatus(gpuId, GpuStatus.MAINTENANCE);
        } else if (gpu.getStatus() == GpuStatus.MAINTENANCE) {
            gpus.updateStatus(gpuId, GpuStatus.AVAILABLE);
        }
    }

    /** 0 means gpu_resources.status agrees with resource_allocations for every GPU. */
    public int inconsistentGpuCount() { return gpus.countInconsistent(); }
}
