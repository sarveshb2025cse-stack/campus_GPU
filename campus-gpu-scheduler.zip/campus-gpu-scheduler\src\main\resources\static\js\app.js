// Small helpers: auto-refresh, double-submit guard, VRAM suggestion on the submit form.
(function () {
  function store(key, value) {
    try { if (value === undefined) return localStorage.getItem(key); localStorage.setItem(key, value); } catch (e) { return null; }
    return null;
  }

  // Auto-refresh live pages (dashboard, queue, GPUs ...) every 5 s unless the user switched it off.
  var box = document.getElementById('autorefresh');
  if (box) {
    box.checked = store('autorefresh') !== 'off';
    box.addEventListener('change', function () { store('autorefresh', box.checked ? 'on' : 'off'); });
    setInterval(function () {
      var typing = document.activeElement && /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName);
      if (box.checked && !typing && !document.hidden) location.reload();
    }, 5000);
  }

  // Disable buttons after submit so a form cannot be sent twice.
  document.querySelectorAll('form').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (e.defaultPrevented) return;
      var b = f.querySelector('button[type=submit]');
      if (b) { setTimeout(function () { b.disabled = true; b.textContent = 'Working…'; }, 0); }
    });
  });

  // Submit Job: suggest the workload's default VRAM until the user types their own value.
  var wl = document.getElementById('workloadType');
  var vram = document.getElementById('vramGb');
  if (wl && vram) {
    var touched = vram.value !== '';
    vram.addEventListener('input', function () { touched = true; });
    wl.addEventListener('change', function () {
      var opt = wl.options[wl.selectedIndex];
      if (!touched && opt && opt.dataset.vram) vram.value = opt.dataset.vram;
    });
  }
})();
