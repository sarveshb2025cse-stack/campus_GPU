package com.campus.gpuscheduler.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class SettingsRepository {
    public static final String POLICY = "scheduling_policy";
    public static final String AUTO_TICK = "auto_tick";

    private final JdbcTemplate jdbc;

    public SettingsRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public String get(String key, String defaultValue) {
        return jdbc.query("SELECT setting_value FROM scheduler_settings WHERE setting_key = ?",
                (rs, i) -> rs.getString(1), key).stream().findFirst().orElse(defaultValue);
    }

    public void set(String key, String value) {
        int updated = jdbc.update("UPDATE scheduler_settings SET setting_value = ? WHERE setting_key = ?", value, key);
        if (updated == 0) {
            jdbc.update("INSERT INTO scheduler_settings (setting_key, setting_value) VALUES (?,?)", key, value);
        }
    }
}
