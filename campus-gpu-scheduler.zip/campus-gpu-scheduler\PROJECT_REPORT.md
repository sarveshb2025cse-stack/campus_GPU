# Campus GPU – Compute Queue & Job Scheduler
### A Java OOP and DBMS-Based System for Shared Campus Computing Resources

---

## 1. Title page
**Project:** Campus GPU / Compute Queue & Job Scheduler
**Team:** Team 29
**Department:** Artificial Intelligence and Machine Learning
**College:** Rajalakshmi Engineering College, Chennai
**Programme:** B.Tech Artificial Intelligence and Machine Learning
**Submitted by:** see section 2

## 2. Team information
| Name | Register number | Role |
|---|---|---|
| Sarvesh B | 251501135 | Team Leader |
| Jatin Dhave | 251501161 | Member |
| Sakthi Sridhar B | 251501172 | Member |
| Sreedevi Prasad | 251501080 | Member |

## 3. Abstract
Shared computing resources such as GPUs are requested by many users at once, but there is usually no central place to
queue requests, see queue positions, apply fair-use rules or keep a record of usage. This project builds a centralized
web application, written in Java (Spring Boot) with a MySQL database, in which students and faculty submit compute jobs,
jobs wait in a queue, and a scheduler assigns **simulated** GPU nodes using a pluggable policy (First-Come-First-Served or
Priority). The system validates requests, enforces exclusive and atomic GPU allocation, estimates waiting time, simulates
job execution and records every status change. The project demonstrates object-oriented design (encapsulation,
inheritance, abstraction, polymorphism, exception handling) and relational database design (keys, joins, transactions,
constraints). GPU execution is simulated; no physical GPU is controlled.

## 4. Introduction
Campus labs often own a few powerful GPUs that many students need for model training and experiments. Without a
scheduler, access is informal and opaque. A queue-and-scheduler system makes access transparent and fair, and it is also
a good vehicle for practising Java OOP and DBMS concepts together. This report describes the design and implementation of
a working prototype built from the Team 29 proposal.

## 5. Problem statement
Shared compute faces: limited resources, conflicting requests, poor visibility into queue position and waiting time,
difficulty enforcing fair use, and no central job history. The proposal states clearly that this is a *general* problem and
that the team has **not** collected data on GPU demand at the college. The project builds a prototype that addresses these
problems in a simulated setting.

## 6. Objectives
1. Accept and validate compute-job requests from students and faculty.
2. Maintain a centralized, database-backed queue.
3. Select jobs with a configurable policy (FCFS or Priority).
4. Allocate simulated GPUs exclusively and atomically, and release them on completion or failure.
5. Show queue position, estimated wait and status.
6. Record job history and usage in MySQL.
7. Demonstrate Java OOP and relational DBMS concepts.

## 7. Scope
**In scope:** login and roles; job submission, queue, cancel, history; GPU inventory; FCFS/Priority scheduling;
per-role fair-use limits; wait estimation; simulated execution, telemetry and failure; admin settings; usage reports.
**Out of scope:** real GPU control, real CUDA execution, real hardware monitoring, email notifications, multi-node clusters.

## 8. Existing system and proposed system
**Existing (typical):** informal sharing, spreadsheets or messaging; no queue visibility, no audit trail, no enforced limits.
**Proposed:** a web application with a MySQL-backed queue, policy-based scheduler, exclusive allocation enforced by the
database, transparent status pages and a complete history.

## 9. Technology stack
| Layer | Technology |
|---|---|
| Language | Java 21 |
| Framework | Spring Boot 3.3.5 (Spring MVC) |
| Presentation | Thymeleaf, HTML, CSS, a little JavaScript |
| Data access | Spring JDBC (`JdbcTemplate`), parameterized SQL |
| Database | MySQL 8 (H2 in MySQL mode for tests/demo) |
| Security | Session login, BCrypt (spring-security-crypto), CSRF token, role interceptor |
| Build / test | Maven, JUnit 5, Spring Boot Test / MockMvc |

The proposal listed "Java 17+"; the project uses Java 21.

## 10. System architecture
![Architecture](docs/diagrams/arch.png)

Controllers handle HTTP and call services. Services contain the rules (validation, scheduling, allocation, estimation)
and use repositories that run parameterized SQL through `JdbcTemplate`. A background ticker calls the scheduler every few
seconds (the admin can switch it off and tick manually).

## 11. System workflow
![Workflow](docs/diagrams/workflow.png)

## 12. UML class diagram
![Class diagram](docs/diagrams/class.png)

## 13. Use-case diagram
![Use cases](docs/diagrams/usecase.png)

## 14. ER diagram
![ER diagram](docs/diagrams/er.png)

## 15. Database table descriptions
See `DATABASE_DESIGN.md` for full details. Summary:

| Table | Description |
|---|---|
| users | Accounts with BCrypt hash and role |
| jobs | One row per job request with its resource request, priority, status and timestamps |
| gpu_resources | The simulated GPU nodes (model, VRAM, cores, status) |
| resource_allocations | History of which job held which GPU; the generated column `active_gpu_lock` + UNIQUE enforces one active allocation per GPU |
| job_status_history | One row for each status change with a note |
| scheduler_settings | Active policy and automatic-tick switch |

## 16. OOP concepts implemented
| Concept | Where in the code |
|---|---|
| **Classes and objects** | `ComputeJob`, `GpuResource`, `User`, `SchedulerService`, `QueueEstimator`, `Telemetry` |
| **Encapsulation** | Private fields with getters in `ComputeJob`, `GpuResource`, `User`; state changes go through methods such as `GpuResource.allocate()/release()` and `JobService.transition()` |
| **Inheritance** | `Student`, `Faculty`, `Admin` extend abstract `User` |
| **Abstraction** | Abstract `User` (role limits); `SchedulingPolicy` interface defines "how to order the queue" without saying how |
| **Polymorphism** | `SchedulerService` calls `order()` on whichever `SchedulingPolicy` is active (`FcfsPolicy` or `PriorityPolicy`), switched at runtime; each role overrides `getMaxPriority()`, `getMaxActiveJobs()`, `getMaxRunningJobs()` |
| **Exception handling** | `JobValidationException` (field errors shown on the form), `AllocationException`, `InvalidTransitionException`, `ForbiddenException`, `NotFoundException`; handled by `GlobalAdvice` and the form controller; the scheduler catches a failed job start, rolls back to the savepoint and continues |
| **JDBC / JdbcTemplate** | All `*Repository` classes |
| **SQL joins** | `GpuRepository.findAllWithActiveJob` (LEFT JOINs), `JobRepository.usageByUser` (LEFT JOIN + GROUP BY), `AllocationRepository.findByJob` (JOIN) |
| **CRUD** | Create job (`insert`), Read (`find*`), Update (`updateStatus`, settings, GPU status), "Delete" as status CANCELLED (history is kept on purpose) |
| **Transactions** | `@Transactional` services, `TransactionTemplate` for ticks, nested savepoint per job start, `SELECT … FOR UPDATE` |
| **Primary / foreign keys** | PKs on every table; FKs `jobs.user_id`, `resource_allocations.job_id/gpu_id`, `job_status_history.job_id` |

## 17. Scheduling algorithms
- **FCFS:** order by `submitted_at`, then `job_id`.
- **Priority:** order by `priority` descending (1–5), then `submitted_at`, then `job_id`. Equal priorities therefore follow submission order.
- **Fair use:** at submission a user may have at most N queued+running jobs (Student 3, Faculty 6, Admin 10) and may request priority up to Student 3, Faculty/Admin 5. At scheduling time a user may have at most 1/2/4 *running* jobs.
- **Eligibility:** jobs are considered in policy order; a job that does not fit right now (not enough free GPUs with enough VRAM, or owner at the running limit) is skipped for that tick and tried again on the next. This means a smaller later job can start while a larger earlier job waits – a simplification (no reservation/backfill rules).

**Wait estimate (`QueueEstimator`):** the queue is walked in policy order; each job is "placed" on the GPUs that become free earliest and have enough VRAM, using the remaining simulated time of running jobs and the requested duration of jobs ahead. For one GPU and two 30-minute jobs ahead it gives 60 minutes, matching the worked example in the proposal. It is approximate: it ignores per-user running limits and future submissions. The recent-average duration (last 5 completed jobs, default 30) is also shown.

## 18. GPU allocation methodology
1. Lock candidate GPUs: `SELECT … FOR UPDATE` over GPUs that are AVAILABLE, have no active allocation and have ≥ the requested VRAM (smallest sufficient GPU first).
2. If fewer than `gpu_count` are found, change nothing (the job stays queued).
3. Otherwise, for each chosen GPU: `GpuResource.allocate()`, insert an allocation row, set the GPU BUSY.
4. Mark the job RUNNING and write history. Steps 3–4 run inside one savepoint, so either every GPU of the job is allocated or none.
5. On COMPLETED / FAILED / CANCELLED the job's allocations get `released_at`, and its GPUs return to AVAILABLE (a GPU in MAINTENANCE stays in maintenance).
6. The UNIQUE constraint on `active_gpu_lock` is the last line of defence against double allocation. An allocation is exclusive: one job owns the entire GPU.

## 19. Implementation details
- **Packages:** `model`, `scheduler`, `repository`, `service`, `web`, `config`, `exception`.
- **Job life-cycle:** `JobStatus.canTransitionTo` allows QUEUED→RUNNING|CANCELLED and RUNNING→COMPLETED|FAILED|CANCELLED only; all changes pass through `JobService.transition`.
- **Simulation:** progress = elapsed time since `started_at` ÷ (`duration_min` × `sim.seconds-per-minute`); a job completes at the first tick after that time. Temperature, power and utilization come from `Telemetry.simulate` (a smooth function of time and GPU id, hotter when busy). They are generated, not measured.
- **Security:** BCrypt hashes, session-based login with session-id change on login, role checks in `AccessInterceptor` (`/admin/**` admin only, `/reports` faculty/admin), per-session CSRF token on all POST forms, students can only open their own jobs, only owner or admin can cancel.
- **UI:** dark navy theme, responsive tables and cards, field-level validation messages, empty states, success/error banners, auto-refresh toggle, buttons disabled after submit.
- **Submit Job page:** workload options show `label (defaultVramGb GB suggested)` using real `WorkloadType` getters.

## 20. Screenshots
*Placeholders – capture these from the running application and paste them before printing.*

| Figure | Page |
|---|---|
| Fig. 1 | Login page |
| Fig. 2 | Dashboard |
| Fig. 3 | Submit Job (with a validation error) |
| Fig. 4 | Job Queue with a running job |
| Fig. 5 | Job detail with status history |
| Fig. 6 | GPU Resources |
| Fig. 7 | Admin – Scheduler settings |
| Fig. 8 | Usage reports |

## 21. Testing and results
**Test code written (in `src/test/java`):**
- `SchedulingPolicyTest` – FCFS order, Priority order, equal-priority order, empty queue, policy swap
- `QueueEstimatorTest` – proposal worked example (30 min average, 60 min wait), multi-GPU wait, impossible requests
- `ModelTest` – validation, status transitions, GPU allocate/release, role limits, progress
- `SchedulerIntegrationTest` (database-backed, H2 in MySQL mode) – submission validation, fair-use limit, exclusive allocation, all-or-nothing multi-GPU, database rejects second active allocation, VRAM matching, maintenance, FCFS vs Priority start order, running limit, completion/failure/cancel release, history trail, illegal transitions
- `WebFlowTest` (MockMvc) – login, wrong password, CSRF, role access, Submit Job page renders, form errors, and the full demo workflow (admin → student submit → admin tick → RUNNING → completion → GPUs released → history)

**Results actually obtained so far:**
| Check | Result |
|---|---|
| Dependency-free core (policies, estimator, status machine, validation, GPU object, progress, role limits) compiled with `javac` and exercised by a 27-assertion harness | **27 passed, 0 failed** |
| Whole project parsed with `javac` (only missing-library errors; no syntax or other type errors; an `assertEquals(int, Integer)` ambiguity was found and fixed) | done |
| `mvn clean test` (Spring/JUnit/MockMvc suites above) | **Not run in the development sandbox** – it could not download Maven dependencies. Run it on your machine and record the numbers here: Tests run: ___ , Failures: ___ , Errors: ___ |
| Running application against MySQL, browser walkthrough of `DEMO_GUIDE.md` | **Not yet performed** – follow the guide and tick the table below |

**Manual test checklist (fill in when you run it):**
| Step | Pass / Fail |
|---|---|
| App starts, dashboard loads | |
| Submit Job page loads, no Thymeleaf error | |
| Invalid submission shows messages | |
| Valid submission appears in queue | |
| Student blocked from `/admin/settings` | |
| Admin tick starts the job (RUNNING, GPU BUSY) | |
| Job completes, GPU AVAILABLE again | |
| Job history shows QUEUED → RUNNING → COMPLETED | |
| Restart keeps all data | |

## 22. Limitations
- GPU allocation and execution are **simulated**; no real hardware is controlled.
- Wait-time estimates are approximate.
- Policies are simplified compared with production schedulers (no backfill rules, preemption, reservations or quotas by time).
- Telemetry is generated, not measured.
- No password reset, account management UI or login rate-limiting.
- The proposal's demand for GPUs at the college has not been measured.

## 23. Future enhancements
- Integration with a real compute server, if available (resource discovery, execution control, monitoring).
- More advanced queue policies (fair-share, backfill, preemption).
- Duration prediction from job history.
- More utilization and fairness reports; notifications.

## 24. Conclusion
The project delivers a database-backed job queue and scheduler for shared (simulated) GPU resources that makes access
transparent and consistent, and it applies Java OOP and relational DBMS concepts in a single working application.

## 25. References
1. Spring Boot Reference Documentation – https://docs.spring.io/spring-boot/
2. Spring Framework: Data Access with JDBC – https://docs.spring.io/spring-framework/reference/data-access/jdbc.html
3. Thymeleaf Documentation – https://www.thymeleaf.org/documentation.html
4. MySQL 8.0 Reference Manual (generated columns, InnoDB locking reads) – https://dev.mysql.com/doc/refman/8.0/en/
5. Silberschatz, Korth, Sudarshan – *Database System Concepts*
6. Silberschatz, Galvin, Gagne – *Operating System Concepts* (CPU/process scheduling: FCFS, priority)
7. Team 29 proposal deck, *Campus GPU / Compute Queue & Job Scheduler*
