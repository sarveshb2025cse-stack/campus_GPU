package com.campus.gpuscheduler.scheduler;

/** Maps a stored policy name to its strategy object. */
public final class Policies {
    private Policies() { }

    public static SchedulingPolicy byName(String name) {
        if ("PRIORITY".equalsIgnoreCase(name)) return new PriorityPolicy();
        return new FcfsPolicy();
    }
}
