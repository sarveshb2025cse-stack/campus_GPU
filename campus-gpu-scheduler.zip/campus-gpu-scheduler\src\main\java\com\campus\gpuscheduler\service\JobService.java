package com.campus.gpuscheduler.service;

import com.campus.gpuscheduler.exception.ForbiddenException;
import com.campus.gpuscheduler.exception.InvalidTransitionException;
import com.campus.gpuscheduler.exception.JobValidationException;
import com.campus.gpuscheduler.exception.NotFoundException;
import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.JobStatus;
import com.campus.gpuscheduler.model.SessionUser;
import com.campus.gpuscheduler.model.User;
import com.campus.gpuscheduler.repository.AllocationRepository;
import com.campus.gpuscheduler.repository.GpuRepository;
import com.campus.gpuscheduler.repository.HistoryRepository;
import com.campus.gpuscheduler.repository.JobRepository;
import com.campus.gpuscheduler.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class JobService {
    public record JobDetail(ComputeJob job, List<HistoryRepository.Entry> history,
                            List<AllocationRepository.Row> allocations, int progress, int remainingMin) {
    /** Bean-style getter so templates can read job. */
    public ComputeJob getJob() { return job; }
    /** Bean-style getter so templates can read history. */
    public List<HistoryRepository.Entry> getHistory() { return history; }
    /** Bean-style getter so templates can read allocations. */
    public List<AllocationRepository.Row> getAllocations() { return allocations; }
    /** Bean-style getter so templates can read progress. */
    public int getProgress() { return progress; }
    /** Bean-style getter so templates can read remainingMin. */
    public int getRemainingMin() { return remainingMin; }
 }

    private final JobRepository jobs;
    private final UserRepository users;
    private final GpuRepository gpus;
    private final HistoryRepository history;
    private final AllocationRepository allocations;
    private final AllocationService allocationService;
    private final SimSettings sim;

    public JobService(JobRepository jobs, UserRepository users, GpuRepository gpus, HistoryRepository history,
                      AllocationRepository allocations, AllocationService allocationService, SimSettings sim) {
        this.jobs = jobs;
        this.users = users;
        this.gpus = gpus;
        this.history = history;
        this.allocations = allocations;
        this.allocationService = allocationService;
        this.sim = sim;
    }

    /** Validates and queues a new job. Returns the new job id. */
    @Transactional
    public int submit(SessionUser submitter, ComputeJob job) {
        job.validate();                                   // field-level rules
        User user = users.findById(submitter.getId())
                .orElseThrow(() -> new NotFoundException("User not found"));

        Map<String, String> errors = new LinkedHashMap<>();
        if (job.getPriority() > user.getMaxPriority()) {
            errors.put("priority", "Your role (" + user.getRole() + ") can request priority up to " + user.getMaxPriority());
        }
        List<GpuRepository.GpuRow> all = gpus.findAllWithActiveJob();
        long compatible = all.stream()
                .filter(r -> r.gpu().getStatus() != com.campus.gpuscheduler.model.GpuStatus.MAINTENANCE)
                .filter(r -> r.gpu().getVramGb() >= job.getVramGb()).count();
        int largest = all.stream().mapToInt(r -> r.gpu().getVramGb()).max().orElse(0);
        if (job.getVramGb() > largest) {
            errors.put("vramGb", "No GPU has " + job.getVramGb() + " GB (largest is " + largest + " GB)");
        } else if (compatible < job.getGpuCount()) {
            errors.put("gpuCount", "Only " + compatible + " in-service GPU(s) have at least " + job.getVramGb()
                    + " GB, so " + job.getGpuCount() + " GPUs can never be allocated");
        }
        if (!errors.isEmpty()) throw new JobValidationException(errors);

        if (jobs.countActiveByUser(user.getUserId()) >= user.getMaxActiveJobs()) {
            throw new JobValidationException(Map.of("jobName", "Fair-use limit reached: you may have at most "
                    + user.getMaxActiveJobs() + " queued/running jobs. Wait for one to finish or cancel one."));
        }

        LocalDateTime now = sim.now();
        job.setUserId(user.getUserId());
        job.setStatus(JobStatus.QUEUED);
        job.setSubmittedAt(now);
        int id = jobs.insert(job);
        history.add(id, null, JobStatus.QUEUED, now, "Job submitted");
        return id;
    }

    /**
     * Single place where a job's status changes. Checks the transition is legal, updates the row with a
     * compare-and-set, writes history, and releases GPUs when the job reaches a terminal status.
     */
    @Transactional
    public void transition(int jobId, JobStatus to, String note) {
        ComputeJob job = jobs.findById(jobId).orElseThrow(() -> new NotFoundException("Job " + jobId + " not found"));
        JobStatus from = job.getStatus();
        if (!from.canTransitionTo(to)) {
            throw new InvalidTransitionException("Job " + jobId + " is " + from + " and cannot become " + to);
        }
        LocalDateTime now = sim.now();
        LocalDateTime started = to == JobStatus.RUNNING ? now : job.getStartedAt();
        LocalDateTime finished = to.isTerminal() ? now : null;
        if (jobs.updateStatus(jobId, from, to, started, finished) == 0) {
            throw new InvalidTransitionException("Job " + jobId + " was changed by someone else; try again");
        }
        history.add(jobId, from, to, now, note);
        if (to.isTerminal()) allocationService.release(jobId);
    }

    @Transactional
    public void cancel(SessionUser actor, int jobId) {
        ComputeJob job = jobs.findById(jobId).orElseThrow(() -> new NotFoundException("Job " + jobId + " not found"));
        if (!actor.isAdmin() && job.getUserId() != actor.getId()) {
            throw new ForbiddenException("You can only cancel your own jobs");
        }
        transition(jobId, JobStatus.CANCELLED, "Cancelled by " + actor.getFullName());
    }

    /** Admin tool to demonstrate failure handling: a RUNNING job fails and its GPUs are released. */
    @Transactional
    public void failRunning(SessionUser actor, int jobId) {
        if (!actor.isAdmin()) throw new ForbiddenException("Only an administrator can fail a job");
        transition(jobId, JobStatus.FAILED, "Simulated failure triggered by " + actor.getFullName());
    }

    public JobDetail detail(SessionUser viewer, int jobId) {
        ComputeJob job = jobs.findById(jobId).orElseThrow(() -> new NotFoundException("Job " + jobId + " not found"));
        if (viewer.isStudent() && job.getUserId() != viewer.getId()) {
            throw new ForbiddenException("You can only view your own jobs");
        }
        LocalDateTime now = sim.now();
        double spm = sim.secondsPerMinute();
        return new JobDetail(job, history.findByJob(jobId), allocations.findByJob(jobId),
                job.progressPercent(now, spm), (int) Math.ceil(job.remainingSimMinutes(now, spm)));
    }

    public List<ComputeJob> jobsOf(SessionUser user) { return jobs.findByUser(user.getId()); }

    /** Faculty and admins see every job; students only their own. */
    public List<ComputeJob> visibleJobs(SessionUser user) {
        return user.isStudent() ? jobs.findByUser(user.getId()) : jobs.findAll();
    }
}
