package com.campus.gpuscheduler.model;

/**
 * Abstract base for all users (inheritance + abstraction).
 * Each role supplies its own fair-use limits (polymorphism).
 */
public abstract class User {
    private final int userId;
    private final String username;
    private final String fullName;
    private final String email;

    protected User(int userId, String username, String fullName, String email) {
        this.userId = userId;
        this.username = username;
        this.fullName = fullName;
        this.email = email;
    }

    public int getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }

    public abstract Role getRole();
    /** Max jobs that may be QUEUED + RUNNING at the same time. */
    public abstract int getMaxActiveJobs();
    /** Max jobs of this user that may RUN at the same time. */
    public abstract int getMaxRunningJobs();
    /** Highest priority (1-5) this user may request. */
    public abstract int getMaxPriority();

    /** Factory that builds the right subclass for a role. */
    public static User create(Role role, int id, String username, String fullName, String email) {
        return switch (role) {
            case STUDENT -> new Student(id, username, fullName, email);
            case FACULTY -> new Faculty(id, username, fullName, email);
            case ADMIN -> new Admin(id, username, fullName, email);
        };
    }
}
