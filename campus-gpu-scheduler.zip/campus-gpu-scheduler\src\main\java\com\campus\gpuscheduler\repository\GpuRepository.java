package com.campus.gpuscheduler.repository;

import com.campus.gpuscheduler.model.GpuResource;
import com.campus.gpuscheduler.model.GpuStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class GpuRepository {
    /** A GPU plus the job currently holding it (LEFT JOIN on the active allocation). */
    public record GpuRow(GpuResource gpu, Integer activeJobId, String activeJobName) {
    /** Bean-style getter so templates can read gpu. */
    public GpuResource getGpu() { return gpu; }
    /** Bean-style getter so templates can read activeJobId. */
    public Integer getActiveJobId() { return activeJobId; }
    /** Bean-style getter so templates can read activeJobName. */
    public String getActiveJobName() { return activeJobName; }
 }

    /** Per-GPU allocation count for the usage report. */
    public record GpuUsage(String gpuName, long allocations) {
    /** Bean-style getter so templates can read gpuName. */
    public String getGpuName() { return gpuName; }
    /** Bean-style getter so templates can read allocations. */
    public long getAllocations() { return allocations; }
 }

    private static final RowMapper<GpuResource> MAPPER = (rs, i) -> new GpuResource(
            rs.getInt("gpu_id"), rs.getString("gpu_name"), rs.getString("gpu_type"), rs.getInt("vram_gb"),
            rs.getInt("cores"), GpuStatus.valueOf(rs.getString("status")));

    private final JdbcTemplate jdbc;

    public GpuRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public List<GpuRow> findAllWithActiveJob() {
        return jdbc.query("SELECT g.*, j.job_id AS active_job_id, j.job_name AS active_job_name "
                        + "FROM gpu_resources g "
                        + "LEFT JOIN resource_allocations a ON a.gpu_id = g.gpu_id AND a.released_at IS NULL "
                        + "LEFT JOIN jobs j ON j.job_id = a.job_id ORDER BY g.gpu_id",
                (rs, i) -> {
                    int jobId = rs.getInt("active_job_id");
                    Integer active = rs.wasNull() ? null : jobId;
                    return new GpuRow(MAPPER.mapRow(rs, i), active, rs.getString("active_job_name"));
                });
    }

    public Optional<GpuResource> findById(int id) {
        return jdbc.query("SELECT * FROM gpu_resources WHERE gpu_id = ?", MAPPER, id).stream().findFirst();
    }

    /**
     * Locks (SELECT ... FOR UPDATE) the free GPUs that have enough VRAM, smallest sufficient GPU first.
     * "Free" = status AVAILABLE and no active allocation row.
     */
    public List<GpuResource> findFreeCompatibleForUpdate(int minVramGb) {
        return jdbc.query("SELECT g.* FROM gpu_resources g WHERE g.status = 'AVAILABLE' AND g.vram_gb >= ? "
                + "AND NOT EXISTS (SELECT 1 FROM resource_allocations a WHERE a.gpu_id = g.gpu_id AND a.released_at IS NULL) "
                + "ORDER BY g.vram_gb, g.gpu_id FOR UPDATE", MAPPER, minVramGb);
    }

    public int updateStatus(int gpuId, GpuStatus status) {
        return jdbc.update("UPDATE gpu_resources SET status = ? WHERE gpu_id = ?", status.name(), gpuId);
    }

    /** GPUs marked BUSY with no active allocation, or AVAILABLE with one. Should always be empty. */
    public int countInconsistent() {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM gpu_resources g WHERE "
                + "(g.status = 'BUSY' AND NOT EXISTS (SELECT 1 FROM resource_allocations a WHERE a.gpu_id = g.gpu_id AND a.released_at IS NULL)) "
                + "OR (g.status <> 'BUSY' AND EXISTS (SELECT 1 FROM resource_allocations a WHERE a.gpu_id = g.gpu_id AND a.released_at IS NULL))",
                Integer.class);
        return n == null ? 0 : n;
    }

    public List<GpuUsage> usage() {
        return jdbc.query("SELECT g.gpu_name, COUNT(a.allocation_id) AS allocations FROM gpu_resources g "
                        + "LEFT JOIN resource_allocations a ON a.gpu_id = g.gpu_id GROUP BY g.gpu_id, g.gpu_name ORDER BY g.gpu_id",
                (rs, i) -> new GpuUsage(rs.getString("gpu_name"), rs.getLong("allocations")));
    }
}
