package com.campus.gpuscheduler.scheduler;

import com.campus.gpuscheduler.model.ComputeJob;

import java.util.Comparator;
import java.util.List;

/** Higher priority first; equal priorities fall back to submission order. */
public class PriorityPolicy implements SchedulingPolicy {
    @Override public String name() { return "PRIORITY"; }

    @Override
    public List<ComputeJob> order(List<ComputeJob> queued) {
        return queued.stream()
                .sorted(Comparator.comparingInt(ComputeJob::getPriority).reversed()
                        .thenComparing(ComputeJob::getSubmittedAt)
                        .thenComparingInt(ComputeJob::getJobId))
                .toList();
    }
}
