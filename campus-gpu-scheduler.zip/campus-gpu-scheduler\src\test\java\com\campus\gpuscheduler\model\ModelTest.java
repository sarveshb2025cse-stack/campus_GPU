package com.campus.gpuscheduler.model;

import com.campus.gpuscheduler.exception.AllocationException;
import com.campus.gpuscheduler.exception.JobValidationException;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class ModelTest {

    @Test void validJobPasses() {
        assertDoesNotThrow(() -> new ComputeJob(1, "ok", WorkloadType.INFERENCE, 1, 8, 10, 1).validate());
    }

    @Test void invalidJobReportsEveryBadField() {
        JobValidationException e = assertThrows(JobValidationException.class,
                () -> new ComputeJob(1, " ", null, 0, 0, 0, 9).validate());
        assertEquals(6, e.getFieldErrors().size());
    }

    @Test void workloadTypeExposesRealProperties() {
        assertEquals(16, WorkloadType.TRAINING.getDefaultVramGb());
        assertEquals("Model training", WorkloadType.TRAINING.getLabel());
    }

    @Test void statusTransitionsFollowTheLifecycle() {
        assertTrue(JobStatus.QUEUED.canTransitionTo(JobStatus.RUNNING));
        assertTrue(JobStatus.QUEUED.canTransitionTo(JobStatus.CANCELLED));
        assertFalse(JobStatus.QUEUED.canTransitionTo(JobStatus.COMPLETED));
        assertTrue(JobStatus.RUNNING.canTransitionTo(JobStatus.COMPLETED));
        assertTrue(JobStatus.RUNNING.canTransitionTo(JobStatus.FAILED));
        assertFalse(JobStatus.COMPLETED.canTransitionTo(JobStatus.RUNNING));
        assertFalse(JobStatus.CANCELLED.canTransitionTo(JobStatus.QUEUED));
    }

    @Test void gpuAllocateAndRelease() {
        GpuResource g = new GpuResource(1, "GPU-01", "t", 24, 100, GpuStatus.AVAILABLE);
        g.allocate();
        assertEquals(GpuStatus.BUSY, g.getStatus());
        assertThrows(AllocationException.class, g::allocate);
        g.release();
        assertTrue(g.isAvailable());
    }

    @Test void maintenanceGpuCannotBeAllocatedOrReleasedIntoService() {
        GpuResource g = new GpuResource(1, "GPU-01", "t", 24, 100, GpuStatus.MAINTENANCE);
        assertThrows(AllocationException.class, g::allocate);
        g.release();
        assertEquals(GpuStatus.MAINTENANCE, g.getStatus());
    }

    @Test void rolesHaveDifferentLimits() {
        User s = User.create(Role.STUDENT, 1, "s", "S", "s@x");
        User f = User.create(Role.FACULTY, 2, "f", "F", "f@x");
        assertInstanceOf(Student.class, s);
        assertInstanceOf(Faculty.class, f);
        assertTrue(s.getMaxPriority() < f.getMaxPriority());
        assertTrue(s.getMaxActiveJobs() < f.getMaxActiveJobs());
    }

    @Test void progressIsComputedFromSimulatedTime() {
        ComputeJob j = new ComputeJob(1, "r", WorkloadType.TRAINING, 1, 8, 10, 1);
        LocalDateTime t0 = LocalDateTime.of(2026, 11, 4, 10, 0);
        j.setStatus(JobStatus.RUNNING);
        j.setStartedAt(t0);
        assertEquals(50, j.progressPercent(t0.plusSeconds(15), 3.0));
        assertFalse(j.isSimulationFinished(t0.plusSeconds(29), 3.0));
        assertTrue(j.isSimulationFinished(t0.plusSeconds(30), 3.0));
    }
}
