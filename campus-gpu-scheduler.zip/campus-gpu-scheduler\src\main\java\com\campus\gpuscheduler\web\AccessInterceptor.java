package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.model.SessionUser;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

/**
 * Session-based access control:
 *  - every POST must carry the session's CSRF token
 *  - everything except /login needs a logged-in user
 *  - /admin/** is ADMIN only, /reports is FACULTY or ADMIN
 */
@Component
public class AccessInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) throws Exception {
        String path = req.getRequestURI().substring(req.getContextPath().length());
        HttpSession session = req.getSession(true);

        if ("POST".equalsIgnoreCase(req.getMethod()) && !validCsrf(req, session)) {
            res.sendError(HttpServletResponse.SC_FORBIDDEN, "Invalid or missing form token. Reload the page and try again.");
            return false;
        }
        if (path.equals("/login")) return true;

        SessionUser user = Sessions.user(session);
        if (user == null) {
            res.sendRedirect(req.getContextPath() + "/login");
            return false;
        }
        if (path.startsWith("/admin") && !user.isAdmin()) {
            res.sendError(HttpServletResponse.SC_FORBIDDEN, "Administrator access required");
            return false;
        }
        if (path.startsWith("/reports") && !user.isCanViewReports()) {
            res.sendError(HttpServletResponse.SC_FORBIDDEN, "Faculty or administrator access required");
            return false;
        }
        return true;
    }

    private boolean validCsrf(HttpServletRequest req, HttpSession session) {
        Object expected = session.getAttribute(Sessions.CSRF);
        String actual = req.getParameter("_csrf");
        if (expected == null || actual == null) return false;
        return MessageDigest.isEqual(expected.toString().getBytes(StandardCharsets.UTF_8),
                actual.getBytes(StandardCharsets.UTF_8));
    }
}
