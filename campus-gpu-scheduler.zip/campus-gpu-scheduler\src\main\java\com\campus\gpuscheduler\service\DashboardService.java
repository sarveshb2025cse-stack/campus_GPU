package com.campus.gpuscheduler.service;

import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.GpuStatus;
import com.campus.gpuscheduler.model.JobStatus;
import com.campus.gpuscheduler.repository.JobRepository;
import com.campus.gpuscheduler.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/** Collects the numbers for the dashboard. Everything comes from the database. */
@Service
public class DashboardService {
    public record Dashboard(int totalGpus, int totalVramGb, int availableGpus, int busyGpus, int maintenanceGpus,
                            int utilizationPct, int queued, int running, int completed, int failed, int cancelled,
                            int clusterUsers, int avgDurationMin, String policy, boolean autoTick,
                            List<GpuService.GpuView> gpus, List<QueueService.QueueRow> queue,
                            List<QueueService.RunningRow> runningJobs, List<ComputeJob> recent,
                            int inconsistentGpus) {
    /** Bean-style getter so templates can read totalGpus. */
    public int getTotalGpus() { return totalGpus; }
    /** Bean-style getter so templates can read totalVramGb. */
    public int getTotalVramGb() { return totalVramGb; }
    /** Bean-style getter so templates can read availableGpus. */
    public int getAvailableGpus() { return availableGpus; }
    /** Bean-style getter so templates can read busyGpus. */
    public int getBusyGpus() { return busyGpus; }
    /** Bean-style getter so templates can read maintenanceGpus. */
    public int getMaintenanceGpus() { return maintenanceGpus; }
    /** Bean-style getter so templates can read utilizationPct. */
    public int getUtilizationPct() { return utilizationPct; }
    /** Bean-style getter so templates can read queued. */
    public int getQueued() { return queued; }
    /** Bean-style getter so templates can read running. */
    public int getRunning() { return running; }
    /** Bean-style getter so templates can read completed. */
    public int getCompleted() { return completed; }
    /** Bean-style getter so templates can read failed. */
    public int getFailed() { return failed; }
    /** Bean-style getter so templates can read cancelled. */
    public int getCancelled() { return cancelled; }
    /** Bean-style getter so templates can read clusterUsers. */
    public int getClusterUsers() { return clusterUsers; }
    /** Bean-style getter so templates can read avgDurationMin. */
    public int getAvgDurationMin() { return avgDurationMin; }
    /** Bean-style getter so templates can read policy. */
    public String getPolicy() { return policy; }
    /** Bean-style getter so templates can read autoTick. */
    public boolean getAutoTick() { return autoTick; }
    /** Bean-style getter so templates can read gpus. */
    public List<GpuService.GpuView> getGpus() { return gpus; }
    /** Bean-style getter so templates can read queue. */
    public List<QueueService.QueueRow> getQueue() { return queue; }
    /** Bean-style getter so templates can read runningJobs. */
    public List<QueueService.RunningRow> getRunningJobs() { return runningJobs; }
    /** Bean-style getter so templates can read recent. */
    public List<ComputeJob> getRecent() { return recent; }
    /** Bean-style getter so templates can read inconsistentGpus. */
    public int getInconsistentGpus() { return inconsistentGpus; }
 }

    private final GpuService gpuService;
    private final QueueService queueService;
    private final JobRepository jobs;
    private final UserRepository users;
    private final SettingsService settings;

    public DashboardService(GpuService gpuService, QueueService queueService, JobRepository jobs,
                            UserRepository users, SettingsService settings) {
        this.gpuService = gpuService;
        this.queueService = queueService;
        this.jobs = jobs;
        this.users = users;
        this.settings = settings;
    }

    public Dashboard build() {
        List<GpuService.GpuView> gpus = gpuService.views();
        int total = gpus.size();
        int vram = gpus.stream().mapToInt(v -> v.gpu().getVramGb()).sum();
        int busy = (int) gpus.stream().filter(v -> v.gpu().getStatus() == GpuStatus.BUSY).count();
        int maintenance = (int) gpus.stream().filter(v -> v.gpu().getStatus() == GpuStatus.MAINTENANCE).count();
        int available = total - busy - maintenance;
        int inService = total - maintenance;
        int util = inService == 0 ? 0 : Math.round(100f * busy / inService);
        Map<JobStatus, Integer> counts = jobs.countByStatus();
        return new Dashboard(total, vram, available, busy, maintenance, util,
                counts.get(JobStatus.QUEUED), counts.get(JobStatus.RUNNING), counts.get(JobStatus.COMPLETED),
                counts.get(JobStatus.FAILED), counts.get(JobStatus.CANCELLED), users.count(),
                queueService.averageDuration(), settings.currentPolicy().name(), settings.isAutoTickOn(),
                gpus, queueService.queue(), queueService.running(), jobs.findRecentFinished(5),
                gpuService.inconsistentGpuCount());
    }
}
