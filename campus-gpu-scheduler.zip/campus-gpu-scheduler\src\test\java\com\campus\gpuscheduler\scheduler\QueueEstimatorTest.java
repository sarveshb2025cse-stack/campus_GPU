package com.campus.gpuscheduler.scheduler;

import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.WorkloadType;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class QueueEstimatorTest {
    private final QueueEstimator estimator = new QueueEstimator();

    private ComputeJob job(int id, int gpus, int vram, int duration) {
        ComputeJob j = new ComputeJob(1, "j" + id, WorkloadType.TRAINING, gpus, vram, duration, 1);
        j.setJobId(id);
        j.setSubmittedAt(LocalDateTime.of(2026, 11, 4, 10, id));
        return j;
    }

    @Test void averageMatchesTheWorkedExampleInTheProposal() {
        assertEquals(30, estimator.averageDuration(List.of(20, 30, 25, 45, 30)));
        assertEquals(30, estimator.averageDuration(List.of()));
    }

    @Test void twoJobsAheadOnOneGpuWaitSixtyMinutes() {
        Map<Integer, Integer> w = estimator.estimateAll(
                List.of(job(1, 1, 8, 30), job(2, 1, 8, 30), job(3, 1, 8, 30)), List.of(new GpuSlot(1, 24, false, 0)));
        assertEquals(0, w.get(1).intValue());
        assertEquals(30, w.get(2).intValue());
        assertEquals(60, w.get(3).intValue());
    }

    @Test void multiGpuJobWaitsForTheLastGpuItNeeds() {
        Map<Integer, Integer> w = estimator.estimateAll(List.of(job(1, 2, 8, 10)),
                List.of(new GpuSlot(1, 24, false, 0), new GpuSlot(2, 24, false, 15)));
        assertEquals(15, w.get(1).intValue());
    }

    @Test void impossibleOrMaintenanceOnlyJobsGetNoEstimate() {
        Map<Integer, Integer> tooBig = estimator.estimateAll(List.of(job(1, 1, 60, 10)), List.of(new GpuSlot(1, 24, false, 0)));
        assertTrue(tooBig.containsKey(1));
        assertNull(tooBig.get(1));
        Map<Integer, Integer> maint = estimator.estimateAll(List.of(job(2, 1, 8, 10)), List.of(new GpuSlot(1, 24, true, 0)));
        assertNull(maint.get(2));
    }
}
