package com.campus.gpuscheduler.model;

import java.io.Serializable;

/** What is kept in the HTTP session after login (no password data). */
public class SessionUser implements Serializable {
    private final int id;
    private final String username;
    private final String fullName;
    private final Role role;

    public SessionUser(int id, String username, String fullName, Role role) {
        this.id = id;
        this.username = username;
        this.fullName = fullName;
        this.role = role;
    }

    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getFullName() { return fullName; }
    public Role getRole() { return role; }
    public boolean isAdmin() { return role == Role.ADMIN; }
    public boolean isFaculty() { return role == Role.FACULTY; }
    public boolean isStudent() { return role == Role.STUDENT; }
    public boolean isCanViewReports() { return role != Role.STUDENT; }
}
