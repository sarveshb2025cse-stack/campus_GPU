package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.exception.ForbiddenException;
import com.campus.gpuscheduler.exception.InvalidTransitionException;
import com.campus.gpuscheduler.exception.NotFoundException;
import com.campus.gpuscheduler.model.SessionUser;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;

/** Adds the logged-in user + CSRF token to every page and turns exceptions into friendly error pages. */
@ControllerAdvice
public class GlobalAdvice {

    @ModelAttribute("currentUser")
    public SessionUser currentUser(HttpSession session) { return Sessions.user(session); }

    @ModelAttribute("csrf")
    public String csrf(HttpSession session) { return Sessions.csrf(session); }

    @ExceptionHandler(NotFoundException.class)
    public String notFound(NotFoundException e, Model model, jakarta.servlet.http.HttpServletResponse res) {
        return error(model, res, HttpStatus.NOT_FOUND, e.getMessage());
    }

    @ExceptionHandler(ForbiddenException.class)
    public String forbidden(ForbiddenException e, Model model, jakarta.servlet.http.HttpServletResponse res) {
        return error(model, res, HttpStatus.FORBIDDEN, e.getMessage());
    }

    @ExceptionHandler(InvalidTransitionException.class)
    public String conflict(InvalidTransitionException e, Model model, jakarta.servlet.http.HttpServletResponse res) {
        return error(model, res, HttpStatus.CONFLICT, e.getMessage());
    }

    private String error(Model model, jakarta.servlet.http.HttpServletResponse res, HttpStatus status, String message) {
        res.setStatus(status.value());
        model.addAttribute("status", status.value());
        model.addAttribute("error", status.getReasonPhrase());
        model.addAttribute("message", message);
        return "error";
    }
}
