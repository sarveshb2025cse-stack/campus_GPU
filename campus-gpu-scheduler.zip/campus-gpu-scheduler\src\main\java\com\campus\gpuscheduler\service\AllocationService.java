package com.campus.gpuscheduler.service;

import com.campus.gpuscheduler.exception.AllocationException;
import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.GpuResource;
import com.campus.gpuscheduler.repository.AllocationRepository;
import com.campus.gpuscheduler.repository.GpuRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/** Allocates and releases whole GPUs for jobs (exclusive policy, all-or-nothing for multi-GPU jobs). */
@Service
public class AllocationService {
    private final GpuRepository gpus;
    private final AllocationRepository allocations;
    private final SimSettings sim;

    public AllocationService(GpuRepository gpus, AllocationRepository allocations, SimSettings sim) {
        this.gpus = gpus;
        this.allocations = allocations;
        this.sim = sim;
    }

    /**
     * Tries to allocate {@code job.gpuCount} free GPUs with enough VRAM.
     * Returns the allocated GPUs, or an empty list (and changes nothing) if not enough are free.
     * If any insert fails the exception propagates so the caller's transaction/savepoint rolls back everything.
     */
    @Transactional
    public List<GpuResource> tryAllocate(ComputeJob job) {
        List<GpuResource> free = gpus.findFreeCompatibleForUpdate(job.getVramGb());   // row locks
        if (free.size() < job.getGpuCount()) return List.of();
        List<GpuResource> chosen = new ArrayList<>(free.subList(0, job.getGpuCount()));
        try {
            for (GpuResource g : chosen) {
                g.allocate();                                    // AVAILABLE -> BUSY (in memory)
                allocations.insert(job.getJobId(), g.getGpuId(), sim.now());   // unique constraint = last line of defence
                gpus.updateStatus(g.getGpuId(), g.getStatus());  // keep gpu_resources in sync
            }
        } catch (DataIntegrityViolationException e) {
            throw new AllocationException("GPU already allocated to another active job", e);
        }
        return chosen;
    }

    /** Closes every active allocation of the job and frees the GPUs (BUSY -> AVAILABLE). */
    @Transactional
    public void release(int jobId) {
        List<Integer> gpuIds = allocations.activeGpuIdsForJob(jobId);
        if (gpuIds.isEmpty()) return;
        allocations.releaseForJob(jobId, sim.now());
        for (int id : gpuIds) {
            gpus.findById(id).ifPresent(g -> {
                g.release();
                gpus.updateStatus(g.getGpuId(), g.getStatus());
            });
        }
    }
}
