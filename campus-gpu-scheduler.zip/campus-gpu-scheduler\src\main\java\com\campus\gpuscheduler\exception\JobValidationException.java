package com.campus.gpuscheduler.exception;

import java.util.Map;

/** Thrown when a job request is invalid. Carries one message per form field. */
public class JobValidationException extends RuntimeException {
    private final Map<String, String> fieldErrors;

    public JobValidationException(Map<String, String> fieldErrors) {
        super("Invalid job request: " + fieldErrors);
        this.fieldErrors = fieldErrors;
    }

    public Map<String, String> getFieldErrors() { return fieldErrors; }
}
