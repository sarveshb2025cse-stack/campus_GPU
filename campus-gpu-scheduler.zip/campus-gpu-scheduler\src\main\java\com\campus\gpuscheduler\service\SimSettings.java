package com.campus.gpuscheduler.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDateTime;

/** Simulation time helper: current time and the "1 simulated minute = N real seconds" factor. */
@Component
public class SimSettings {
    private final Clock clock;
    private final double secondsPerMinute;

    public SimSettings(Clock clock, @Value("${sim.seconds-per-minute:3}") double secondsPerMinute) {
        this.clock = clock;
        this.secondsPerMinute = secondsPerMinute;
    }

    public LocalDateTime now() { return LocalDateTime.now(clock); }
    public double secondsPerMinute() { return secondsPerMinute; }
}
