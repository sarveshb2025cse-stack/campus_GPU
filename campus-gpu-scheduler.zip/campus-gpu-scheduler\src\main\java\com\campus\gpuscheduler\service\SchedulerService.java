package com.campus.gpuscheduler.service;

import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.GpuResource;
import com.campus.gpuscheduler.model.JobStatus;
import com.campus.gpuscheduler.model.User;
import com.campus.gpuscheduler.repository.JobRepository;
import com.campus.gpuscheduler.repository.UserRepository;
import com.campus.gpuscheduler.scheduler.SchedulingPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

/**
 * The scheduler. One "tick" = (1) finish simulated jobs whose time is up, (2) start queued jobs.
 * Jobs are considered in the order given by the active SchedulingPolicy; a job that cannot be placed
 * right now (not enough free GPUs, or its owner is at the running limit) is skipped for this tick.
 */
@Service
public class SchedulerService {
    private static final Logger log = LoggerFactory.getLogger(SchedulerService.class);

    public record TickResult(int completed, int started, List<String> messages) {
    /** Bean-style getter so templates can read completed. */
    public int getCompleted() { return completed; }
    /** Bean-style getter so templates can read started. */
    public int getStarted() { return started; }
    /** Bean-style getter so templates can read messages. */
    public List<String> getMessages() { return messages; }
 }

    private final JobRepository jobs;
    private final UserRepository users;
    private final JobService jobService;
    private final AllocationService allocationService;
    private final SettingsService settings;
    private final SimSettings sim;
    private final TransactionTemplate tx;
    private final TransactionTemplate nestedTx;
    private final ReentrantLock lock = new ReentrantLock();

    public SchedulerService(JobRepository jobs, UserRepository users, JobService jobService,
                            AllocationService allocationService, SettingsService settings, SimSettings sim,
                            PlatformTransactionManager txManager) {
        this.jobs = jobs;
        this.users = users;
        this.jobService = jobService;
        this.allocationService = allocationService;
        this.settings = settings;
        this.sim = sim;
        this.tx = new TransactionTemplate(txManager);
        this.nestedTx = new TransactionTemplate(txManager);
        this.nestedTx.setPropagationBehavior(TransactionDefinition.PROPAGATION_NESTED);   // savepoint per job
    }

    /** Runs one scheduler tick. Ticks never overlap (manual button + background timer). */
    public TickResult tick() {
        lock.lock();
        try {
            return tx.execute(status -> doTick());
        } finally {
            lock.unlock();
        }
    }

    private TickResult doTick() {
        LocalDateTime now = sim.now();
        double spm = sim.secondsPerMinute();
        List<String> messages = new ArrayList<>();
        int completed = 0;
        int started = 0;

        // 1. Simulated execution: finish jobs whose run time has elapsed (this also releases their GPUs)
        for (ComputeJob running : jobs.findByStatus(JobStatus.RUNNING)) {
            if (running.isSimulationFinished(now, spm)) {
                jobService.transition(running.getJobId(), JobStatus.COMPLETED, "Simulated run finished");
                messages.add("Job #" + running.getJobId() + " completed");
                completed++;
            }
        }

        // 2. Scheduling: consider queued jobs in policy order
        SchedulingPolicy policy = settings.currentPolicy();
        List<ComputeJob> ordered = policy.order(jobs.findByStatus(JobStatus.QUEUED));
        Map<Integer, Integer> runningByUser = jobs.runningCountByUser();
        for (ComputeJob job : ordered) {
            User owner = users.findById(job.getUserId()).orElse(null);
            if (owner == null) continue;
            if (runningByUser.getOrDefault(owner.getUserId(), 0) >= owner.getMaxRunningJobs()) continue;  // fair use
            try {
                List<GpuResource> gpus = nestedTx.execute(s -> startJob(job));
                if (gpus != null && !gpus.isEmpty()) {
                    runningByUser.merge(owner.getUserId(), 1, Integer::sum);
                    messages.add("Job #" + job.getJobId() + " started on " + names(gpus));
                    started++;
                }
            } catch (RuntimeException e) {
                // the savepoint was rolled back: no GPU of this job stays allocated
                log.warn("Could not start job {}: {}", job.getJobId(), e.getMessage());
                messages.add("Job #" + job.getJobId() + " could not be started: " + e.getMessage());
            }
        }
        return new TickResult(completed, started, messages);
    }

    /** Allocate all requested GPUs, then mark RUNNING. Either both happen or (on exception) neither. */
    private List<GpuResource> startJob(ComputeJob job) {
        List<GpuResource> gpus = allocationService.tryAllocate(job);
        if (gpus.isEmpty()) return List.of();
        jobService.transition(job.getJobId(), JobStatus.RUNNING, "Allocated " + names(gpus) + " (" + policyName() + ")");
        return gpus;
    }

    private String policyName() { return settings.currentPolicy().name(); }

    private static String names(List<GpuResource> gpus) {
        return String.join(", ", gpus.stream().map(GpuResource::getGpuName).toList());
    }
}
