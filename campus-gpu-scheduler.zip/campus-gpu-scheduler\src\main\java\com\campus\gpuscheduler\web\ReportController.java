package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.service.ReportService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ReportController {
    private final ReportService reports;

    public ReportController(ReportService reports) { this.reports = reports; }

    @GetMapping("/reports")
    public String show(Model model) {
        model.addAttribute("byUser", reports.usageByUser());
        model.addAttribute("byGpu", reports.usageByGpu());
        model.addAttribute("active", "reports");
        return "reports";
    }
}
