package com.campus.gpuscheduler.scheduler;

import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.WorkloadType;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SchedulingPolicyTest {

    private ComputeJob job(int id, int priority, int minute) {
        ComputeJob j = new ComputeJob(1, "job" + id, WorkloadType.TRAINING, 1, 8, 10, priority);
        j.setJobId(id);
        j.setSubmittedAt(LocalDateTime.of(2026, 11, 4, 10, minute));
        return j;
    }

    private List<Integer> ids(List<ComputeJob> jobs) { return jobs.stream().map(ComputeJob::getJobId).toList(); }

    private final List<ComputeJob> queue = List.of(job(1, 1, 5), job(2, 5, 6), job(3, 5, 4), job(4, 3, 7));

    @Test void fcfsOrdersBySubmissionTime() {
        assertEquals(List.of(3, 1, 2, 4), ids(new FcfsPolicy().order(queue)));
    }

    @Test void priorityOrdersHighestFirst() {
        assertEquals(List.of(3, 2, 4, 1), ids(new PriorityPolicy().order(queue)));
    }

    @Test void equalPriorityFollowsSubmissionOrder() {
        List<ComputeJob> same = List.of(job(10, 4, 9), job(11, 4, 3), job(12, 4, 6));
        assertEquals(List.of(11, 12, 10), ids(new PriorityPolicy().order(same)));
    }

    @Test void selectNextHandlesEmptyQueue() {
        assertTrue(new FcfsPolicy().selectNext(List.of()).isEmpty());
        assertEquals(3, new PriorityPolicy().selectNext(queue).orElseThrow().getJobId());
    }

    @Test void policiesAreSwappableThroughTheInterface() {
        SchedulingPolicy p = Policies.byName("PRIORITY");
        assertEquals("PRIORITY", p.name());
        assertEquals("FCFS", Policies.byName("anything else").name());
    }
}
