package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.model.SessionUser;
import com.campus.gpuscheduler.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
public class AuthController {
    private final AuthService auth;

    public AuthController(AuthService auth) { this.auth = auth; }

    @GetMapping("/")
    public String home() { return "redirect:/dashboard"; }

    @GetMapping("/login")
    public String loginPage(HttpSession session) {
        return Sessions.user(session) != null ? "redirect:/dashboard" : "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password,
                        HttpServletRequest request, Model model) {
        Optional<SessionUser> user = auth.authenticate(username, password);
        if (user.isEmpty()) {
            model.addAttribute("loginError", "Invalid username or password");
            model.addAttribute("username", username);
            return "login";
        }
        String csrf = Sessions.csrf(request.getSession());
        request.changeSessionId();                       // prevents session fixation
        HttpSession session = request.getSession();
        session.setAttribute(Sessions.CSRF, csrf);
        session.setAttribute(Sessions.USER, user.get());
        return "redirect:/dashboard";
    }

    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
