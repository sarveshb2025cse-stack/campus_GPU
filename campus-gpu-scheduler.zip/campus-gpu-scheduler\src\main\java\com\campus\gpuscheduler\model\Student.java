package com.campus.gpuscheduler.model;

public class Student extends User {
    public Student(int id, String username, String fullName, String email) { super(id, username, fullName, email); }
    @Override public Role getRole() { return Role.STUDENT; }
    @Override public int getMaxActiveJobs() { return 3; }
    @Override public int getMaxRunningJobs() { return 1; }
    @Override public int getMaxPriority() { return 3; }
}
