package com.campus.gpuscheduler.service;

import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.GpuStatus;
import com.campus.gpuscheduler.model.JobStatus;
import com.campus.gpuscheduler.repository.AllocationRepository;
import com.campus.gpuscheduler.repository.GpuRepository;
import com.campus.gpuscheduler.repository.JobRepository;
import com.campus.gpuscheduler.scheduler.GpuSlot;
import com.campus.gpuscheduler.scheduler.QueueEstimator;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/** Builds the queue / running lists shown on the dashboard and queue page. */
@Service
public class QueueService {
    public record QueueRow(int position, ComputeJob job, Integer estWaitMin) {
    /** Bean-style getter so templates can read position. */
    public int getPosition() { return position; }
    /** Bean-style getter so templates can read job. */
    public ComputeJob getJob() { return job; }
    /** Bean-style getter so templates can read estWaitMin. */
    public Integer getEstWaitMin() { return estWaitMin; }
 }
    public record RunningRow(ComputeJob job, List<String> gpuNames, int progress, int remainingMin) {
    /** Bean-style getter so templates can read job. */
    public ComputeJob getJob() { return job; }
    /** Bean-style getter so templates can read gpuNames. */
    public List<String> getGpuNames() { return gpuNames; }
    /** Bean-style getter so templates can read progress. */
    public int getProgress() { return progress; }
    /** Bean-style getter so templates can read remainingMin. */
    public int getRemainingMin() { return remainingMin; }
 }

    private final JobRepository jobs;
    private final GpuRepository gpus;
    private final AllocationRepository allocations;
    private final SettingsService settings;
    private final SimSettings sim;
    private final QueueEstimator estimator = new QueueEstimator();

    public QueueService(JobRepository jobs, GpuRepository gpus, AllocationRepository allocations,
                        SettingsService settings, SimSettings sim) {
        this.jobs = jobs;
        this.gpus = gpus;
        this.allocations = allocations;
        this.settings = settings;
        this.sim = sim;
    }

    public List<QueueRow> queue() {
        List<ComputeJob> ordered = settings.currentPolicy().order(jobs.findByStatus(JobStatus.QUEUED));
        Map<Integer, Integer> waits = estimator.estimateAll(ordered, slots());
        return java.util.stream.IntStream.range(0, ordered.size())
                .mapToObj(i -> new QueueRow(i + 1, ordered.get(i), waits.get(ordered.get(i).getJobId())))
                .toList();
    }

    public List<RunningRow> running() {
        LocalDateTime now = sim.now();
        double spm = sim.secondsPerMinute();
        return jobs.findByStatus(JobStatus.RUNNING).stream()
                .map(j -> new RunningRow(j, allocations.activeGpuNamesForJob(j.getJobId()),
                        j.progressPercent(now, spm), (int) Math.ceil(j.remainingSimMinutes(now, spm))))
                .toList();
    }

    /** Average of the last 5 completed durations (or the default 30 when nothing has completed yet). */
    public int averageDuration() {
        return estimator.averageDuration(jobs.recentCompletedDurations(5));
    }

    private List<GpuSlot> slots() {
        LocalDateTime now = sim.now();
        double spm = sim.secondsPerMinute();
        Map<Integer, ComputeJob> running = jobs.findByStatus(JobStatus.RUNNING).stream()
                .collect(Collectors.toMap(ComputeJob::getJobId, Function.identity()));
        return gpus.findAllWithActiveJob().stream().map(r -> {
            double busy = 0;
            if (r.activeJobId() != null && running.containsKey(r.activeJobId())) {
                busy = running.get(r.activeJobId()).remainingSimMinutes(now, spm);
            }
            return new GpuSlot(r.gpu().getGpuId(), r.gpu().getVramGb(),
                    r.gpu().getStatus() == GpuStatus.MAINTENANCE, busy);
        }).toList();
    }
}
