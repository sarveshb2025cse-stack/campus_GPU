-- Same schema for H2 (MySQL mode). Used by the h2 demo profile and the automated tests.

CREATE TABLE IF NOT EXISTS users (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  role          VARCHAR(10)  NOT NULL,
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_users_role CHECK (role IN ('STUDENT','FACULTY','ADMIN'))
);

CREATE TABLE IF NOT EXISTS gpu_resources (
  gpu_id    INT AUTO_INCREMENT PRIMARY KEY,
  gpu_name  VARCHAR(50)  NOT NULL UNIQUE,
  gpu_type  VARCHAR(80)  NOT NULL,
  vram_gb   INT          NOT NULL,
  cores     INT          NOT NULL,
  status    VARCHAR(12)  NOT NULL DEFAULT 'AVAILABLE',
  CONSTRAINT chk_gpu_vram CHECK (vram_gb > 0),
  CONSTRAINT chk_gpu_status CHECK (status IN ('AVAILABLE','BUSY','MAINTENANCE'))
);

CREATE TABLE IF NOT EXISTS jobs (
  job_id        INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT          NOT NULL,
  job_name      VARCHAR(100) NOT NULL,
  workload_type VARCHAR(20)  NOT NULL,
  gpu_count     INT          NOT NULL,
  vram_gb       INT          NOT NULL,
  duration_min  INT          NOT NULL,
  priority      INT          NOT NULL DEFAULT 1,
  status        VARCHAR(12)  NOT NULL DEFAULT 'QUEUED',
  submitted_at  TIMESTAMP    NOT NULL,
  started_at    TIMESTAMP    NULL,
  finished_at   TIMESTAMP    NULL,
  CONSTRAINT fk_jobs_user FOREIGN KEY (user_id) REFERENCES users(user_id),
  CONSTRAINT chk_jobs_status CHECK (status IN ('QUEUED','RUNNING','COMPLETED','FAILED','CANCELLED')),
  CONSTRAINT chk_jobs_gpu_count CHECK (gpu_count >= 1),
  CONSTRAINT chk_jobs_duration CHECK (duration_min >= 1),
  CONSTRAINT chk_jobs_priority CHECK (priority BETWEEN 1 AND 5)
);

CREATE TABLE IF NOT EXISTS resource_allocations (
  allocation_id   INT AUTO_INCREMENT PRIMARY KEY,
  job_id          INT       NOT NULL,
  gpu_id          INT       NOT NULL,
  allocated_at    TIMESTAMP NOT NULL,
  released_at     TIMESTAMP NULL,
  active_gpu_lock INT GENERATED ALWAYS AS (CASE WHEN released_at IS NULL THEN gpu_id ELSE NULL END),
  CONSTRAINT fk_alloc_job FOREIGN KEY (job_id) REFERENCES jobs(job_id),
  CONSTRAINT fk_alloc_gpu FOREIGN KEY (gpu_id) REFERENCES gpu_resources(gpu_id),
  CONSTRAINT uq_active_gpu UNIQUE (active_gpu_lock)
);

CREATE TABLE IF NOT EXISTS job_status_history (
  history_id INT AUTO_INCREMENT PRIMARY KEY,
  job_id     INT          NOT NULL,
  old_status VARCHAR(12)  NULL,
  new_status VARCHAR(12)  NOT NULL,
  changed_at TIMESTAMP    NOT NULL,
  note       VARCHAR(255) NULL,
  CONSTRAINT fk_hist_job FOREIGN KEY (job_id) REFERENCES jobs(job_id)
);

CREATE TABLE IF NOT EXISTS scheduler_settings (
  setting_key   VARCHAR(50)  PRIMARY KEY,
  setting_value VARCHAR(100) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_jobs_status_submitted ON jobs(status, submitted_at);
CREATE INDEX IF NOT EXISTS idx_jobs_user ON jobs(user_id);
CREATE INDEX IF NOT EXISTS idx_alloc_job ON resource_allocations(job_id);
CREATE INDEX IF NOT EXISTS idx_hist_job ON job_status_history(job_id);
