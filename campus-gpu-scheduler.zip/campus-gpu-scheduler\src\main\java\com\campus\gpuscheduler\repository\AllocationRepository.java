package com.campus.gpuscheduler.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class AllocationRepository {
    public record Row(String gpuName, LocalDateTime allocatedAt, LocalDateTime releasedAt) {
    /** Bean-style getter so templates can read gpuName. */
    public String getGpuName() { return gpuName; }
    /** Bean-style getter so templates can read allocatedAt. */
    public LocalDateTime getAllocatedAt() { return allocatedAt; }
    /** Bean-style getter so templates can read releasedAt. */
    public LocalDateTime getReleasedAt() { return releasedAt; }
 }

    private final JdbcTemplate jdbc;

    public AllocationRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    /** Inserts an allocation. The UNIQUE(active_gpu_lock) constraint rejects a second active allocation of a GPU. */
    public void insert(int jobId, int gpuId, LocalDateTime at) {
        jdbc.update("INSERT INTO resource_allocations (job_id, gpu_id, allocated_at) VALUES (?,?,?)",
                jobId, gpuId, Timestamp.valueOf(at));
    }

    public List<Integer> activeGpuIdsForJob(int jobId) {
        return jdbc.query("SELECT gpu_id FROM resource_allocations WHERE job_id = ? AND released_at IS NULL ORDER BY gpu_id",
                (rs, i) -> rs.getInt(1), jobId);
    }

    public int releaseForJob(int jobId, LocalDateTime at) {
        return jdbc.update("UPDATE resource_allocations SET released_at = ? WHERE job_id = ? AND released_at IS NULL",
                Timestamp.valueOf(at), jobId);
    }

    public List<String> activeGpuNamesForJob(int jobId) {
        return jdbc.query("SELECT g.gpu_name FROM resource_allocations a JOIN gpu_resources g ON g.gpu_id = a.gpu_id "
                + "WHERE a.job_id = ? AND a.released_at IS NULL ORDER BY g.gpu_id", (rs, i) -> rs.getString(1), jobId);
    }

    public List<Row> findByJob(int jobId) {
        return jdbc.query("SELECT g.gpu_name, a.allocated_at, a.released_at FROM resource_allocations a "
                        + "JOIN gpu_resources g ON g.gpu_id = a.gpu_id WHERE a.job_id = ? ORDER BY a.allocated_at, g.gpu_id",
                (rs, i) -> new Row(rs.getString("gpu_name"), rs.getTimestamp("allocated_at").toLocalDateTime(),
                        rs.getTimestamp("released_at") == null ? null : rs.getTimestamp("released_at").toLocalDateTime()), jobId);
    }
}
