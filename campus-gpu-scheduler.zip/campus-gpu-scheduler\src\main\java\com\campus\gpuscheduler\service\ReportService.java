package com.campus.gpuscheduler.service;

import com.campus.gpuscheduler.repository.GpuRepository;
import com.campus.gpuscheduler.repository.JobRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportService {
    private final JobRepository jobs;
    private final GpuRepository gpus;

    public ReportService(JobRepository jobs, GpuRepository gpus) {
        this.jobs = jobs;
        this.gpus = gpus;
    }

    public List<JobRepository.UserUsage> usageByUser() { return jobs.usageByUser(); }
    public List<GpuRepository.GpuUsage> usageByGpu() { return gpus.usage(); }
}
