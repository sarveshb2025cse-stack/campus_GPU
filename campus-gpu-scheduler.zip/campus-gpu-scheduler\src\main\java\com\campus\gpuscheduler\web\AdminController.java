package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.service.GpuService;
import com.campus.gpuscheduler.service.JobService;
import com.campus.gpuscheduler.service.QueueService;
import com.campus.gpuscheduler.service.SchedulerService;
import com.campus.gpuscheduler.service.SettingsService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Administrator-only actions. Access is enforced by AccessInterceptor (/admin/**). */
@Controller
public class AdminController {
    private final SettingsService settings;
    private final SchedulerService scheduler;
    private final GpuService gpuService;
    private final JobService jobService;
    private final QueueService queueService;

    public AdminController(SettingsService settings, SchedulerService scheduler, GpuService gpuService,
                           JobService jobService, QueueService queueService) {
        this.settings = settings;
        this.scheduler = scheduler;
        this.gpuService = gpuService;
        this.jobService = jobService;
        this.queueService = queueService;
    }

    @GetMapping("/admin/settings")
    public String page(Model model) {
        model.addAttribute("policy", settings.currentPolicy().name());
        model.addAttribute("autoTick", settings.isAutoTickOn());
        model.addAttribute("gpus", gpuService.views());
        model.addAttribute("running", queueService.running());
        model.addAttribute("queue", queueService.queue());
        model.addAttribute("active", "admin");
        model.addAttribute("refresh", true);
        return "admin/settings";
    }

    @PostMapping("/admin/settings/policy")
    public String setPolicy(@RequestParam String policy, RedirectAttributes flash) {
        try {
            settings.setPolicy(policy);
            flash.addFlashAttribute("ok", "Scheduling policy set to " + policy.toUpperCase() + ".");
        } catch (IllegalArgumentException e) {
            flash.addFlashAttribute("err", e.getMessage());
        }
        return "redirect:/admin/settings";
    }

    @PostMapping("/admin/settings/auto-tick")
    public String setAutoTick(@RequestParam String mode, RedirectAttributes flash) {
        settings.setAutoTick("ON".equalsIgnoreCase(mode));
        flash.addFlashAttribute("ok", "Automatic scheduler ticks are now " + ("ON".equalsIgnoreCase(mode) ? "ON" : "OFF") + ".");
        return "redirect:/admin/settings";
    }

    @PostMapping("/admin/tick")
    public String tick(RedirectAttributes flash) {
        SchedulerService.TickResult r = scheduler.tick();
        flash.addFlashAttribute("ok", "Scheduler tick done: " + r.started() + " started, " + r.completed() + " completed."
                + (r.messages().isEmpty() ? "" : " " + String.join("; ", r.messages())));
        return "redirect:/admin/settings";
    }

    @PostMapping("/admin/jobs/{id}/fail")
    public String fail(@PathVariable int id, HttpSession session, RedirectAttributes flash) {
        jobService.failRunning(Sessions.user(session), id);
        flash.addFlashAttribute("ok", "Job #" + id + " marked FAILED (simulated) and its GPUs were released.");
        return "redirect:/admin/settings";
    }

    @PostMapping("/admin/gpus/{id}/maintenance")
    public String maintenance(@PathVariable int id, @RequestParam boolean on, RedirectAttributes flash) {
        try {
            gpuService.setMaintenance(id, on);
            flash.addFlashAttribute("ok", "GPU " + (on ? "set to maintenance." : "returned to service."));
        } catch (IllegalStateException e) {
            flash.addFlashAttribute("err", e.getMessage());
        }
        return "redirect:/admin/settings";
    }
}
