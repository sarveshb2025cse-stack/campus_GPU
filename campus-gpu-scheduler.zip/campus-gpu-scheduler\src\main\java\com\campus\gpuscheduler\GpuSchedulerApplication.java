package com.campus.gpuscheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class GpuSchedulerApplication {
    public static void main(String[] args) {
        SpringApplication.run(GpuSchedulerApplication.class, args);
    }
}
