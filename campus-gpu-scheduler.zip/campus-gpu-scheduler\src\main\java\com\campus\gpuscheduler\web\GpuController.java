package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.service.GpuService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class GpuController {
    private final GpuService gpuService;

    public GpuController(GpuService gpuService) { this.gpuService = gpuService; }

    @GetMapping("/gpus")
    public String list(Model model) {
        model.addAttribute("gpus", gpuService.views());
        model.addAttribute("inconsistent", gpuService.inconsistentGpuCount());
        model.addAttribute("active", "gpus");
        model.addAttribute("refresh", true);
        return "gpus";
    }
}
