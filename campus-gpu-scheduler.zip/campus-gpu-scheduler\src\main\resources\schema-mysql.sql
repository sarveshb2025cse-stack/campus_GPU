-- Campus GPU Scheduler - MySQL 8 schema. Safe to run repeatedly (IF NOT EXISTS, no drops).

CREATE TABLE IF NOT EXISTS users (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  role          VARCHAR(10)  NOT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_users_role CHECK (role IN ('STUDENT','FACULTY','ADMIN'))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS gpu_resources (
  gpu_id    INT AUTO_INCREMENT PRIMARY KEY,
  gpu_name  VARCHAR(50)  NOT NULL UNIQUE,
  gpu_type  VARCHAR(80)  NOT NULL,
  vram_gb   INT          NOT NULL,
  cores     INT          NOT NULL,
  status    VARCHAR(12)  NOT NULL DEFAULT 'AVAILABLE',
  CONSTRAINT chk_gpu_vram CHECK (vram_gb > 0),
  CONSTRAINT chk_gpu_status CHECK (status IN ('AVAILABLE','BUSY','MAINTENANCE'))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS jobs (
  job_id        INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT          NOT NULL,
  job_name      VARCHAR(100) NOT NULL,
  workload_type VARCHAR(20)  NOT NULL,
  gpu_count     INT          NOT NULL,
  vram_gb       INT          NOT NULL,
  duration_min  INT          NOT NULL,
  priority      INT          NOT NULL DEFAULT 1,
  status        VARCHAR(12)  NOT NULL DEFAULT 'QUEUED',
  submitted_at  DATETIME     NOT NULL,
  started_at    DATETIME     NULL,
  finished_at   DATETIME     NULL,
  CONSTRAINT fk_jobs_user FOREIGN KEY (user_id) REFERENCES users(user_id),
  CONSTRAINT chk_jobs_status CHECK (status IN ('QUEUED','RUNNING','COMPLETED','FAILED','CANCELLED')),
  CONSTRAINT chk_jobs_gpu_count CHECK (gpu_count >= 1),
  CONSTRAINT chk_jobs_duration CHECK (duration_min >= 1),
  CONSTRAINT chk_jobs_priority CHECK (priority BETWEEN 1 AND 5),
  INDEX idx_jobs_status_submitted (status, submitted_at),
  INDEX idx_jobs_user (user_id)
) ENGINE=InnoDB;

-- active_gpu_lock is gpu_id while the allocation is active (released_at IS NULL), otherwise NULL.
-- The UNIQUE key on it means a physical GPU can have only ONE active allocation (exclusive policy).
CREATE TABLE IF NOT EXISTS resource_allocations (
  allocation_id   INT AUTO_INCREMENT PRIMARY KEY,
  job_id          INT      NOT NULL,
  gpu_id          INT      NOT NULL,
  allocated_at    DATETIME NOT NULL,
  released_at     DATETIME NULL,
  active_gpu_lock INT GENERATED ALWAYS AS (CASE WHEN released_at IS NULL THEN gpu_id ELSE NULL END) STORED,
  CONSTRAINT fk_alloc_job FOREIGN KEY (job_id) REFERENCES jobs(job_id),
  CONSTRAINT fk_alloc_gpu FOREIGN KEY (gpu_id) REFERENCES gpu_resources(gpu_id),
  CONSTRAINT uq_active_gpu UNIQUE (active_gpu_lock),
  INDEX idx_alloc_job (job_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS job_status_history (
  history_id INT AUTO_INCREMENT PRIMARY KEY,
  job_id     INT          NOT NULL,
  old_status VARCHAR(12)  NULL,
  new_status VARCHAR(12)  NOT NULL,
  changed_at DATETIME     NOT NULL,
  note       VARCHAR(255) NULL,
  CONSTRAINT fk_hist_job FOREIGN KEY (job_id) REFERENCES jobs(job_id),
  INDEX idx_hist_job (job_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scheduler_settings (
  setting_key   VARCHAR(50)  PRIMARY KEY,
  setting_value VARCHAR(100) NOT NULL
) ENGINE=InnoDB;
