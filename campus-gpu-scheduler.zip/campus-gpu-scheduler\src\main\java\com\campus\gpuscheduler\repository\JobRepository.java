package com.campus.gpuscheduler.repository;

import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.JobStatus;
import com.campus.gpuscheduler.model.WorkloadType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class JobRepository {
    /** One row of the per-user usage report (SQL JOIN + GROUP BY). */
    public record UserUsage(String fullName, String role, long totalJobs, long completedJobs, long gpuMinutes) {
    /** Bean-style getter so templates can read fullName. */
    public String getFullName() { return fullName; }
    /** Bean-style getter so templates can read role. */
    public String getRole() { return role; }
    /** Bean-style getter so templates can read totalJobs. */
    public long getTotalJobs() { return totalJobs; }
    /** Bean-style getter so templates can read completedJobs. */
    public long getCompletedJobs() { return completedJobs; }
    /** Bean-style getter so templates can read gpuMinutes. */
    public long getGpuMinutes() { return gpuMinutes; }
 }

    private static final String BASE =
            "SELECT j.*, u.full_name AS owner_name FROM jobs j JOIN users u ON u.user_id = j.user_id ";

    private static final RowMapper<ComputeJob> MAPPER = (rs, i) -> {
        ComputeJob j = new ComputeJob();
        j.setJobId(rs.getInt("job_id"));
        j.setUserId(rs.getInt("user_id"));
        j.setOwnerName(rs.getString("owner_name"));
        j.setJobName(rs.getString("job_name"));
        j.setWorkloadType(WorkloadType.valueOf(rs.getString("workload_type")));
        j.setGpuCount(rs.getInt("gpu_count"));
        j.setVramGb(rs.getInt("vram_gb"));
        j.setDurationMin(rs.getInt("duration_min"));
        j.setPriority(rs.getInt("priority"));
        j.setStatus(JobStatus.valueOf(rs.getString("status")));
        j.setSubmittedAt(toLdt(rs.getTimestamp("submitted_at")));
        j.setStartedAt(toLdt(rs.getTimestamp("started_at")));
        j.setFinishedAt(toLdt(rs.getTimestamp("finished_at")));
        return j;
    };

    private final JdbcTemplate jdbc;

    public JobRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private static LocalDateTime toLdt(Timestamp ts) { return ts == null ? null : ts.toLocalDateTime(); }

    public int insert(ComputeJob j) {
        KeyHolder keys = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO jobs (user_id, job_name, workload_type, gpu_count, vram_gb, duration_min, priority, status, submitted_at) "
                            + "VALUES (?,?,?,?,?,?,?,?,?)", new String[]{"job_id"});
            ps.setInt(1, j.getUserId());
            ps.setString(2, j.getJobName());
            ps.setString(3, j.getWorkloadType().name());
            ps.setInt(4, j.getGpuCount());
            ps.setInt(5, j.getVramGb());
            ps.setInt(6, j.getDurationMin());
            ps.setInt(7, j.getPriority());
            ps.setString(8, j.getStatus().name());
            ps.setTimestamp(9, Timestamp.valueOf(j.getSubmittedAt()));
            return ps;
        }, keys);
        Number key = keys.getKey();
        if (key == null) throw new IllegalStateException("Job insert returned no key");
        return key.intValue();
    }

    public Optional<ComputeJob> findById(int id) {
        return jdbc.query(BASE + "WHERE j.job_id = ?", MAPPER, id).stream().findFirst();
    }

    public List<ComputeJob> findByStatus(JobStatus status) {
        return jdbc.query(BASE + "WHERE j.status = ? ORDER BY j.submitted_at, j.job_id", MAPPER, status.name());
    }

    public List<ComputeJob> findByUser(int userId) {
        return jdbc.query(BASE + "WHERE j.user_id = ? ORDER BY j.submitted_at DESC, j.job_id DESC", MAPPER, userId);
    }

    public List<ComputeJob> findAll() {
        return jdbc.query(BASE + "ORDER BY j.submitted_at DESC, j.job_id DESC", MAPPER);
    }

    public List<ComputeJob> findRecentFinished(int limit) {
        return jdbc.query(BASE + "WHERE j.status IN ('COMPLETED','FAILED','CANCELLED') "
                + "ORDER BY j.finished_at DESC, j.job_id DESC LIMIT ?", MAPPER, limit);
    }

    /**
     * Compare-and-set status change: only succeeds if the row is still in {@code from}.
     * @return rows updated (0 means someone else changed the job first)
     */
    public int updateStatus(int jobId, JobStatus from, JobStatus to, LocalDateTime startedAt, LocalDateTime finishedAt) {
        return jdbc.update("UPDATE jobs SET status = ?, started_at = ?, finished_at = ? WHERE job_id = ? AND status = ?",
                new Object[]{to.name(), startedAt == null ? null : Timestamp.valueOf(startedAt),
                        finishedAt == null ? null : Timestamp.valueOf(finishedAt), jobId, from.name()},
                new int[]{Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP, Types.INTEGER, Types.VARCHAR});
    }

    public int countActiveByUser(int userId) {
        Integer n = jdbc.queryForObject(
                "SELECT COUNT(*) FROM jobs WHERE user_id = ? AND status IN ('QUEUED','RUNNING')", Integer.class, userId);
        return n == null ? 0 : n;
    }

    public Map<Integer, Integer> runningCountByUser() {
        Map<Integer, Integer> map = new HashMap<>();
        jdbc.query("SELECT user_id, COUNT(*) AS c FROM jobs WHERE status = 'RUNNING' GROUP BY user_id",
                rs -> { map.put(rs.getInt("user_id"), rs.getInt("c")); });
        return map;
    }

    public Map<JobStatus, Integer> countByStatus() {
        Map<JobStatus, Integer> map = new LinkedHashMap<>();
        for (JobStatus s : JobStatus.values()) map.put(s, 0);
        jdbc.query("SELECT status, COUNT(*) AS c FROM jobs GROUP BY status",
                rs -> { map.put(JobStatus.valueOf(rs.getString("status")), rs.getInt("c")); });
        return map;
    }

    public List<Integer> recentCompletedDurations(int limit) {
        return jdbc.query("SELECT duration_min FROM jobs WHERE status = 'COMPLETED' "
                + "ORDER BY finished_at DESC, job_id DESC LIMIT ?", (rs, i) -> rs.getInt(1), limit);
    }

    public List<UserUsage> usageByUser() {
        return jdbc.query("SELECT u.full_name, u.role, COUNT(j.job_id) AS total_jobs, "
                + "COALESCE(SUM(CASE WHEN j.status = 'COMPLETED' THEN 1 ELSE 0 END), 0) AS completed_jobs, "
                + "COALESCE(SUM(CASE WHEN j.status = 'COMPLETED' THEN j.duration_min * j.gpu_count ELSE 0 END), 0) AS gpu_minutes "
                + "FROM users u LEFT JOIN jobs j ON j.user_id = u.user_id "
                + "GROUP BY u.user_id, u.full_name, u.role ORDER BY gpu_minutes DESC, u.full_name",
                (rs, i) -> new UserUsage(rs.getString("full_name"), rs.getString("role"),
                        rs.getLong("total_jobs"), rs.getLong("completed_jobs"), rs.getLong("gpu_minutes")));
    }
}
