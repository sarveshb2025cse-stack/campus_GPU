package com.campus.gpuscheduler.service;

import com.campus.gpuscheduler.repository.SettingsRepository;
import com.campus.gpuscheduler.scheduler.Policies;
import com.campus.gpuscheduler.scheduler.SchedulingPolicy;
import org.springframework.stereotype.Service;

@Service
public class SettingsService {
    private final SettingsRepository settings;

    public SettingsService(SettingsRepository settings) { this.settings = settings; }

    public SchedulingPolicy currentPolicy() {
        return Policies.byName(settings.get(SettingsRepository.POLICY, "FCFS"));
    }

    public void setPolicy(String name) {
        if (!"FCFS".equalsIgnoreCase(name) && !"PRIORITY".equalsIgnoreCase(name)) {
            throw new IllegalArgumentException("Unknown scheduling policy: " + name);
        }
        settings.set(SettingsRepository.POLICY, name.toUpperCase());
    }

    public boolean isAutoTickOn() {
        return "ON".equalsIgnoreCase(settings.get(SettingsRepository.AUTO_TICK, "ON"));
    }

    public void setAutoTick(boolean on) {
        settings.set(SettingsRepository.AUTO_TICK, on ? "ON" : "OFF");
    }
}
