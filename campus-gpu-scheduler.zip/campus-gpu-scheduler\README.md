# Campus GPU – Compute Queue & Job Scheduler

**Team 29 · Dept. of Artificial Intelligence and Machine Learning · Rajalakshmi Engineering College**
Sarvesh B (251501135, Team Leader) · Jatin Dhave (251501161) · Sakthi Sridhar B (251501172) · Sreedevi Prasad (251501080)

A Java OOP + MySQL application that lets students and faculty submit compute jobs, queues them, and schedules them
onto **simulated** GPU nodes with FCFS or Priority policy. It is built from the Team 29 proposal deck.

> **Prototype notice.** GPU allocation, execution, temperature, power and utilization are all *simulated*.
> No physical GPU is connected and no CUDA workload is run.

## Stack
Java 21 · Spring Boot 3.3.5 · Maven · Spring JDBC (`JdbcTemplate`, parameterized SQL) · Thymeleaf · HTML/CSS/JS · MySQL 8 · JUnit 5

## Run it (PowerShell)

Requirements: JDK 21, Maven 3.9+. MySQL 8 is optional (see option B).

**A. With MySQL** – the app creates the database `campus_gpu_prototype` and its tables if they do not exist
(`CREATE ... IF NOT EXISTS`; nothing is dropped or deleted):
```powershell
cd campus-gpu-scheduler
$env:DB_USER = "root"
$env:DB_PASSWORD = "your-mysql-password"
mvn spring-boot:run
```
To use another database, set `$env:DB_URL = "jdbc:mysql://localhost:3306/yourdb?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true"`.

**B. Without MySQL** (embedded H2 in MySQL mode, data kept in `./data`):
```powershell
mvn spring-boot:run "-Dspring-boot.run.profiles=h2"
```
Open <http://localhost:8080>.

**Tests**
```powershell
mvn clean test
```

## Demo accounts (seeded only when the tables are empty)
| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Faculty | `faculty1` | `faculty123` |
| Student | `student1` … `student4` | `student123` |

Passwords are stored as BCrypt hashes. Change them before any real use.

## Features
- Session login/logout, BCrypt hashes, role-based access (Student / Faculty / Admin), CSRF token on every POST
- Dashboard with live database numbers: GPUs, VRAM, available/busy, queued/running/completed, users, simulated telemetry
- Submit Job with validation (name, workload, GPUs, VRAM, duration, priority limited by role)
- Job queue with position, priority, estimated wait, cancel; running jobs with simulated progress
- My Jobs / All Jobs, job detail with status history and GPU allocations
- GPU resources page (allocation consistency check), usage reports (SQL JOIN + GROUP BY)
- Admin: FCFS/Priority switch, run scheduler tick, auto-tick on/off, GPU maintenance, simulate job failure

## How scheduling works (short)
One *tick* = (1) complete simulated jobs whose time is up and release their GPUs, (2) order the queue with the active
policy, (3) start each job that fits. A job is skipped for this tick if its owner is at the running limit
(Student 1, Faculty 2, Admin 4) or not enough free GPUs with enough VRAM exist. Multi-GPU jobs are allocated
all-or-nothing using a savepoint. A GPU is held by one job at a time; the database enforces this with the generated
column `active_gpu_lock` + UNIQUE constraint.

1 simulated minute = `sim.seconds-per-minute` real seconds (default 3, see `application.properties`).

## Documents
`PROJECT_REPORT.md` · `DATABASE_DESIGN.md` · `DEMO_GUIDE.md` · diagrams in `docs/diagrams/`

## Project layout
```
src/main/java/com/campus/gpuscheduler
  model/       User (abstract) + Student/Faculty/Admin, ComputeJob, GpuResource, enums
  scheduler/   SchedulingPolicy, FcfsPolicy, PriorityPolicy, QueueEstimator, Telemetry
  repository/  JdbcTemplate repositories
  service/     JobService, SchedulerService, AllocationService, GpuService, QueueService, ...
  web/         controllers, access interceptor, form object
src/main/resources  templates/, static/, schema-mysql.sql, schema-h2.sql
src/test/java       unit + integration tests
```

## Known limitations
See section 22 of `PROJECT_REPORT.md`. Notably: simulated execution only; estimates are approximate; no login
rate-limiting; the scheduler may start a smaller later job while a larger earlier job waits for free GPUs (no reservation/backfill rules).
