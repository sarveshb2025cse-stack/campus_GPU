package com.campus.gpuscheduler.model;

import com.campus.gpuscheduler.exception.JobValidationException;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/** A compute job request. Fields are private; state is read through getters (encapsulation). */
public class ComputeJob {
    public static final int MIN_PRIORITY = 1;
    public static final int MAX_PRIORITY = 5;
    public static final int MAX_GPU_COUNT = 8;
    public static final int MAX_VRAM_GB = 80;
    public static final int MAX_DURATION_MIN = 1440;

    private int jobId;
    private int userId;
    private String ownerName;
    private String jobName;
    private WorkloadType workloadType;
    private int gpuCount;
    private int vramGb;
    private int durationMin;
    private int priority;
    private JobStatus status = JobStatus.QUEUED;
    private LocalDateTime submittedAt;
    private LocalDateTime startedAt;
    private LocalDateTime finishedAt;

    public ComputeJob() { }

    public ComputeJob(int userId, String jobName, WorkloadType workloadType,
                      int gpuCount, int vramGb, int durationMin, int priority) {
        this.userId = userId;
        this.jobName = jobName;
        this.workloadType = workloadType;
        this.gpuCount = gpuCount;
        this.vramGb = vramGb;
        this.durationMin = durationMin;
        this.priority = priority;
    }

    /** Checks the fields that do not depend on cluster state. Throws with one message per field. */
    public void validate() {
        Map<String, String> errors = new LinkedHashMap<>();
        if (jobName == null || jobName.isBlank()) errors.put("jobName", "Job name is required");
        else if (jobName.length() > 100) errors.put("jobName", "Job name must be at most 100 characters");
        if (workloadType == null) errors.put("workloadType", "Select a workload type");
        if (gpuCount < 1 || gpuCount > MAX_GPU_COUNT)
            errors.put("gpuCount", "GPU count must be between 1 and " + MAX_GPU_COUNT);
        if (vramGb < 1 || vramGb > MAX_VRAM_GB)
            errors.put("vramGb", "VRAM must be between 1 and " + MAX_VRAM_GB + " GB");
        if (durationMin < 1 || durationMin > MAX_DURATION_MIN)
            errors.put("durationMin", "Duration must be between 1 and " + MAX_DURATION_MIN + " minutes");
        if (priority < MIN_PRIORITY || priority > MAX_PRIORITY)
            errors.put("priority", "Priority must be between " + MIN_PRIORITY + " and " + MAX_PRIORITY);
        if (!errors.isEmpty()) throw new JobValidationException(errors);
    }

    /** Simulated progress 0-100. 1 simulated minute = secondsPerSimMinute real seconds. */
    public int progressPercent(LocalDateTime now, double secondsPerSimMinute) {
        if (status == JobStatus.COMPLETED) return 100;
        if (status != JobStatus.RUNNING || startedAt == null) return 0;
        double total = durationMin * secondsPerSimMinute;
        double elapsed = elapsedSeconds(now);
        return (int) Math.max(0, Math.min(100, Math.floor(elapsed / total * 100)));
    }

    /** True once the simulated run time has fully elapsed. */
    public boolean isSimulationFinished(LocalDateTime now, double secondsPerSimMinute) {
        return status == JobStatus.RUNNING && startedAt != null
                && elapsedSeconds(now) >= durationMin * secondsPerSimMinute;
    }

    /** Remaining simulated minutes (0 when finished or not running). */
    public double remainingSimMinutes(LocalDateTime now, double secondsPerSimMinute) {
        if (status != JobStatus.RUNNING || startedAt == null) return 0;
        return Math.max(0, durationMin - elapsedSeconds(now) / secondsPerSimMinute);
    }

    private double elapsedSeconds(LocalDateTime now) {
        return Duration.between(startedAt, now).toMillis() / 1000.0;
    }

    public int getJobId() { return jobId; }
    public void setJobId(int jobId) { this.jobId = jobId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    public String getJobName() { return jobName; }
    public void setJobName(String jobName) { this.jobName = jobName; }
    public WorkloadType getWorkloadType() { return workloadType; }
    public void setWorkloadType(WorkloadType workloadType) { this.workloadType = workloadType; }
    public int getGpuCount() { return gpuCount; }
    public void setGpuCount(int gpuCount) { this.gpuCount = gpuCount; }
    public int getVramGb() { return vramGb; }
    public void setVramGb(int vramGb) { this.vramGb = vramGb; }
    public int getDurationMin() { return durationMin; }
    public void setDurationMin(int durationMin) { this.durationMin = durationMin; }
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    public JobStatus getStatus() { return status; }
    public void setStatus(JobStatus status) { this.status = status; }
    public LocalDateTime getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(LocalDateTime submittedAt) { this.submittedAt = submittedAt; }
    public LocalDateTime getStartedAt() { return startedAt; }
    public void setStartedAt(LocalDateTime startedAt) { this.startedAt = startedAt; }
    public LocalDateTime getFinishedAt() { return finishedAt; }
    public void setFinishedAt(LocalDateTime finishedAt) { this.finishedAt = finishedAt; }
}
