package com.campus.gpuscheduler.repository;

import com.campus.gpuscheduler.model.JobStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class HistoryRepository {
    public record Entry(JobStatus oldStatus, JobStatus newStatus, LocalDateTime changedAt, String note) {
    /** Bean-style getter so templates can read oldStatus. */
    public JobStatus getOldStatus() { return oldStatus; }
    /** Bean-style getter so templates can read newStatus. */
    public JobStatus getNewStatus() { return newStatus; }
    /** Bean-style getter so templates can read changedAt. */
    public LocalDateTime getChangedAt() { return changedAt; }
    /** Bean-style getter so templates can read note. */
    public String getNote() { return note; }
 }

    private final JdbcTemplate jdbc;

    public HistoryRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public void add(int jobId, JobStatus oldStatus, JobStatus newStatus, LocalDateTime at, String note) {
        jdbc.update("INSERT INTO job_status_history (job_id, old_status, new_status, changed_at, note) VALUES (?,?,?,?,?)",
                jobId, oldStatus == null ? null : oldStatus.name(), newStatus.name(), Timestamp.valueOf(at), note);
    }

    public List<Entry> findByJob(int jobId) {
        return jdbc.query("SELECT old_status, new_status, changed_at, note FROM job_status_history "
                        + "WHERE job_id = ? ORDER BY changed_at, history_id",
                (rs, i) -> new Entry(
                        rs.getString("old_status") == null ? null : JobStatus.valueOf(rs.getString("old_status")),
                        JobStatus.valueOf(rs.getString("new_status")),
                        rs.getTimestamp("changed_at").toLocalDateTime(), rs.getString("note")), jobId);
    }
}
