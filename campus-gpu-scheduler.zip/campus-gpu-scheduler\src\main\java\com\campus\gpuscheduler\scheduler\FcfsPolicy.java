package com.campus.gpuscheduler.scheduler;

import com.campus.gpuscheduler.model.ComputeJob;

import java.util.Comparator;
import java.util.List;

/** First come, first served: ordered by submission time (job id breaks exact ties). */
public class FcfsPolicy implements SchedulingPolicy {
    @Override public String name() { return "FCFS"; }

    @Override
    public List<ComputeJob> order(List<ComputeJob> queued) {
        return queued.stream()
                .sorted(Comparator.comparing(ComputeJob::getSubmittedAt).thenComparingInt(ComputeJob::getJobId))
                .toList();
    }
}
