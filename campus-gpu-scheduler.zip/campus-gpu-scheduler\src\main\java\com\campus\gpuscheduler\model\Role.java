package com.campus.gpuscheduler.model;

public enum Role { STUDENT, FACULTY, ADMIN }
