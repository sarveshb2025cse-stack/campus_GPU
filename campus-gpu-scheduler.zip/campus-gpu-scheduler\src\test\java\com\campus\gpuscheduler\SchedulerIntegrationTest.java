package com.campus.gpuscheduler;

import com.campus.gpuscheduler.exception.ForbiddenException;
import com.campus.gpuscheduler.exception.InvalidTransitionException;
import com.campus.gpuscheduler.exception.JobValidationException;
import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.JobStatus;
import com.campus.gpuscheduler.model.SessionUser;
import com.campus.gpuscheduler.model.WorkloadType;
import com.campus.gpuscheduler.repository.HistoryRepository;
import com.campus.gpuscheduler.repository.JobRepository;
import com.campus.gpuscheduler.service.GpuService;
import com.campus.gpuscheduler.service.JobService;
import com.campus.gpuscheduler.service.SchedulerService;
import com.campus.gpuscheduler.service.SettingsService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Database-backed tests of submission, scheduling, exclusive allocation, release and transitions. */
class SchedulerIntegrationTest extends IntegrationTestBase {
    @Autowired JobService jobService;
    @Autowired SchedulerService scheduler;
    @Autowired SettingsService settings;
    @Autowired GpuService gpuService;
    @Autowired JobRepository jobs;
    @Autowired HistoryRepository history;

    private int submit(SessionUser u, String name, int gpus, int vram, int minutes, int priority) {
        advanceSeconds(1);   // distinct submission times
        return jobService.submit(u, new ComputeJob(u.getId(), name, WorkloadType.TRAINING, gpus, vram, minutes, priority));
    }

    private JobStatus status(int id) { return jobs.findById(id).orElseThrow().getStatus(); }
    private int activeAllocations() {
        return count("SELECT COUNT(*) FROM resource_allocations WHERE released_at IS NULL");
    }

    // ---------- submission validation ----------
    @Test void priorityAboveRoleLimitIsRejected() {
        JobValidationException e = assertThrows(JobValidationException.class,
                () -> submit(user("student1"), "x", 1, 8, 5, 4));
        assertTrue(e.getFieldErrors().containsKey("priority"));
    }

    @Test void requestNoGpuCanSatisfyIsRejected() {
        JobValidationException e = assertThrows(JobValidationException.class,
                () -> submit(user("faculty1"), "x", 5, 8, 5, 1));   // only 4 GPUs exist
        assertTrue(e.getFieldErrors().containsKey("gpuCount"));
    }

    @Test void fieldValidationRejectsBadValues() {
        assertThrows(JobValidationException.class, () -> submit(user("student1"), " ", 1, 8, 5, 1));
        assertThrows(JobValidationException.class, () -> submit(user("student1"), "x", 1, 8, 0, 1));
    }

    @Test void fairUseLimitStopsTheFourthActiveStudentJob() {
        SessionUser s = user("student1");
        for (int i = 0; i < 3; i++) submit(s, "j" + i, 1, 8, 5, 1);
        assertThrows(JobValidationException.class, () -> submit(s, "one too many", 1, 8, 5, 1));
    }

    // ---------- allocation ----------
    @Test void exclusiveAllocationSecondJobWaitsAndGetsNothingPartially() {
        SessionUser f = user("faculty1");
        int a = submit(f, "A-3gpu", 3, 8, 10, 1);
        int b = submit(f, "B-2gpu", 2, 8, 10, 1);
        SchedulerService.TickResult r = scheduler.tick();
        assertEquals(1, r.started());
        assertEquals(JobStatus.RUNNING, status(a));
        assertEquals(JobStatus.QUEUED, status(b));          // only 1 GPU free: needs 2 -> none allocated
        assertEquals(3, activeAllocations());
        assertEquals(0, count("SELECT COUNT(*) FROM resource_allocations WHERE job_id = ?", b));
        assertEquals(0, gpuService.inconsistentGpuCount());
    }

    @Test void databaseRejectsASecondActiveAllocationOfTheSameGpu() {
        SessionUser f = user("faculty1");
        int a = submit(f, "A", 1, 8, 10, 1);
        int b = submit(f, "B", 1, 8, 10, 1);
        scheduler.tick();
        Integer gpuOfA = count("SELECT gpu_id FROM resource_allocations WHERE job_id = ? AND released_at IS NULL", a);
        assertThrows(DataIntegrityViolationException.class, () -> jdbc.update(
                "INSERT INTO resource_allocations (job_id, gpu_id, allocated_at) VALUES (?,?,?)",
                b, gpuOfA, Timestamp.valueOf(LocalDateTime.now())));
    }

    @Test void vramRequirementIsRespected() {
        int id = submit(user("faculty1"), "big", 1, 60, 5, 1);   // only the 80 GB GPU qualifies
        scheduler.tick();
        assertEquals(JobStatus.RUNNING, status(id));
        String gpu = jdbc.queryForObject("SELECT g.gpu_name FROM resource_allocations a JOIN gpu_resources g ON g.gpu_id = a.gpu_id WHERE a.job_id = ?", String.class, id);
        assertEquals("GPU-04", gpu);
    }

    @Test void maintenanceGpuIsNeverAllocated() {
        gpuService.setMaintenance(1, true);
        gpuService.setMaintenance(2, true);
        gpuService.setMaintenance(3, true);
        int id = submit(user("faculty1"), "j", 1, 8, 5, 1);
        scheduler.tick();
        assertEquals(JobStatus.RUNNING, status(id));
        String gpu = jdbc.queryForObject("SELECT g.gpu_name FROM resource_allocations a JOIN gpu_resources g ON g.gpu_id = a.gpu_id WHERE a.job_id = ?", String.class, id);
        assertEquals("GPU-04", gpu);   // the only GPU left in service
        // and a 2-GPU request can never be satisfied while three GPUs are in maintenance
        assertThrows(JobValidationException.class, () -> submit(user("faculty1"), "k", 2, 8, 5, 1));
    }

    // ---------- scheduling policies ----------
    @Test void fcfsStartsTheEarliestJobFirst() {
        SessionUser f = user("faculty1");
        int first = submit(f, "first", 4, 8, 10, 1);
        int second = submit(f, "urgent", 4, 8, 10, 5);
        settings.setPolicy("FCFS");
        scheduler.tick();
        assertEquals(JobStatus.RUNNING, status(first));
        assertEquals(JobStatus.QUEUED, status(second));
    }

    @Test void priorityStartsTheHighestPriorityJobFirst() {
        SessionUser f = user("faculty1");
        int first = submit(f, "first", 4, 8, 10, 1);
        int urgent = submit(f, "urgent", 4, 8, 10, 5);
        settings.setPolicy("PRIORITY");
        scheduler.tick();
        assertEquals(JobStatus.RUNNING, status(urgent));
        assertEquals(JobStatus.QUEUED, status(first));
    }

    @Test void studentRunningLimitIsEnforcedByTheScheduler() {
        SessionUser s = user("student1");
        int a = submit(s, "a", 1, 8, 10, 1);
        int b = submit(s, "b", 1, 8, 10, 1);
        scheduler.tick();
        assertEquals(JobStatus.RUNNING, status(a));
        assertEquals(JobStatus.QUEUED, status(b));    // students may run only 1 job at a time
    }

    // ---------- execution, release, history ----------
    @Test void completionReleasesGpusAndRecordsHistory() {
        int id = submit(user("faculty1"), "run", 2, 8, 5, 1);   // 5 simulated min = 5 s in tests
        scheduler.tick();
        assertEquals(2, activeAllocations());
        advanceSeconds(3);
        scheduler.tick();
        assertEquals(JobStatus.RUNNING, status(id));            // not finished yet
        advanceSeconds(3);
        scheduler.tick();
        assertEquals(JobStatus.COMPLETED, status(id));
        assertEquals(0, activeAllocations());
        assertEquals(0, count("SELECT COUNT(*) FROM gpu_resources WHERE status = 'BUSY'"));
        assertEquals(0, gpuService.inconsistentGpuCount());
        List<JobStatus> trail = history.findByJob(id).stream().map(HistoryRepository.Entry::newStatus).toList();
        assertEquals(List.of(JobStatus.QUEUED, JobStatus.RUNNING, JobStatus.COMPLETED), trail);
    }

    @Test void failureReleasesGpus() {
        int id = submit(user("faculty1"), "boom", 2, 8, 60, 1);
        scheduler.tick();
        jobService.failRunning(user("admin"), id);
        assertEquals(JobStatus.FAILED, status(id));
        assertEquals(0, activeAllocations());
        assertEquals(0, gpuService.inconsistentGpuCount());
    }

    @Test void onlyAdminCanFailAJob() {
        int id = submit(user("faculty1"), "x", 1, 8, 60, 1);
        scheduler.tick();
        assertThrows(ForbiddenException.class, () -> jobService.failRunning(user("student1"), id));
    }

    @Test void cancellingARunningJobReleasesItsGpus() {
        SessionUser f = user("faculty1");
        int id = submit(f, "c", 2, 8, 60, 1);
        scheduler.tick();
        jobService.cancel(f, id);
        assertEquals(JobStatus.CANCELLED, status(id));
        assertEquals(0, activeAllocations());
    }

    @Test void studentCannotCancelSomeoneElsesJob() {
        int id = submit(user("student1"), "mine", 1, 8, 5, 1);
        assertThrows(ForbiddenException.class, () -> jobService.cancel(user("student2"), id));
        jobService.cancel(user("admin"), id);   // admin may
        assertEquals(JobStatus.CANCELLED, status(id));
    }

    @Test void illegalTransitionsAreRejected() {
        int id = submit(user("student1"), "t", 1, 8, 5, 1);
        assertThrows(InvalidTransitionException.class, () -> jobService.transition(id, JobStatus.COMPLETED, "skip"));
        jobService.cancel(user("student1"), id);
        assertThrows(InvalidTransitionException.class, () -> jobService.transition(id, JobStatus.RUNNING, "back"));
    }
}
