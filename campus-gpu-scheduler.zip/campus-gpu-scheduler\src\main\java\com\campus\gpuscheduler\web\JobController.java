package com.campus.gpuscheduler.web;

import com.campus.gpuscheduler.exception.JobValidationException;
import com.campus.gpuscheduler.model.ComputeJob;
import com.campus.gpuscheduler.model.SessionUser;
import com.campus.gpuscheduler.model.User;
import com.campus.gpuscheduler.model.WorkloadType;
import com.campus.gpuscheduler.repository.UserRepository;
import com.campus.gpuscheduler.service.JobService;
import com.campus.gpuscheduler.service.QueueService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class JobController {
    private final JobService jobService;
    private final QueueService queueService;
    private final UserRepository users;

    public JobController(JobService jobService, QueueService queueService, UserRepository users) {
        this.jobService = jobService;
        this.queueService = queueService;
        this.users = users;
    }

    @GetMapping("/jobs/submit")
    public String submitPage(Model model, HttpSession session) {
        model.addAttribute("form", new SubmitJobForm());
        return submitView(model, Sessions.user(session));
    }

    @PostMapping("/jobs/submit")
    public String submit(@Valid @ModelAttribute("form") SubmitJobForm form, BindingResult result,
                         Model model, HttpSession session, RedirectAttributes flash) {
        SessionUser user = Sessions.user(session);
        if (!result.hasErrors()) {
            ComputeJob job = new ComputeJob(user.getId(), form.getJobName(), form.getWorkloadType(),
                    form.getGpuCount(), form.getVramGb(), form.getDurationMin(), form.getPriority());
            try {
                int id = jobService.submit(user, job);
                flash.addFlashAttribute("ok", "Job #" + id + " \"" + job.getJobName() + "\" was submitted and queued.");
                return "redirect:/jobs/queue";
            } catch (JobValidationException e) {
                e.getFieldErrors().forEach((field, msg) -> {
                    if (result.hasFieldErrors(field) || !hasField(field)) result.reject("job.invalid", msg);
                    else result.rejectValue(field, "job.invalid", msg);
                });
            }
        }
        return submitView(model, user);
    }

    private boolean hasField(String field) {
        return java.util.Set.of("jobName", "workloadType", "gpuCount", "vramGb", "durationMin", "priority").contains(field);
    }

    private String submitView(Model model, SessionUser user) {
        User domainUser = users.findById(user.getId()).orElseThrow();
        model.addAttribute("workloads", WorkloadType.values());
        model.addAttribute("maxPriority", domainUser.getMaxPriority());
        model.addAttribute("maxActive", domainUser.getMaxActiveJobs());
        model.addAttribute("active", "submit");
        return "jobs/submit";
    }

    @GetMapping("/jobs/queue")
    public String queue(Model model) {
        model.addAttribute("queue", queueService.queue());
        model.addAttribute("running", queueService.running());
        model.addAttribute("avgDuration", queueService.averageDuration());
        model.addAttribute("active", "queue");
        model.addAttribute("refresh", true);
        return "jobs/queue";
    }

    @GetMapping("/jobs/mine")
    public String mine(Model model, HttpSession session) {
        SessionUser user = Sessions.user(session);
        model.addAttribute("jobs", jobService.visibleJobs(user));
        model.addAttribute("allJobs", !user.isStudent());
        model.addAttribute("active", "mine");
        model.addAttribute("refresh", true);
        return "jobs/history";
    }

    @GetMapping("/jobs/{id}")
    public String detail(@PathVariable int id, Model model, HttpSession session) {
        model.addAttribute("d", jobService.detail(Sessions.user(session), id));
        model.addAttribute("active", "mine");
        model.addAttribute("refresh", true);
        return "jobs/detail";
    }

    @PostMapping("/jobs/{id}/cancel")
    public String cancel(@PathVariable int id, HttpSession session, RedirectAttributes flash) {
        jobService.cancel(Sessions.user(session), id);
        flash.addFlashAttribute("ok", "Job #" + id + " was cancelled and any GPUs were released.");
        return "redirect:/jobs/queue";
    }
}
