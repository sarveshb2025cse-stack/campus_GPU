package com.campus.gpuscheduler;

import com.campus.gpuscheduler.model.JobStatus;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

/** HTTP-level tests: login, role-based access, CSRF, the Submit Job page and the whole demo workflow. */
class WebFlowTest extends IntegrationTestBase {
    @Autowired MockMvc mvc;

    /** A tiny "browser": keeps one session and its CSRF token. */
    private class Browser {
        MockHttpSession session = new MockHttpSession();

        String token() throws Exception {
            mvc.perform(get("/login").session(session)).andExpect(status().isOk());
            return (String) session.getAttribute("csrfToken");
        }

        void login(String user, String pass) throws Exception {
            String t = token();
            mvc.perform(post("/login").session(session).param("_csrf", t).param("username", user).param("password", pass))
                    .andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/dashboard"));
        }

        String csrf() { return (String) session.getAttribute("csrfToken"); }

        void logout() throws Exception {
            mvc.perform(post("/logout").session(session).param("_csrf", csrf())).andExpect(redirectedUrl("/login"));
            session = new MockHttpSession();
        }
    }

    @Test void anonymousUsersAreSentToLogin() throws Exception {
        mvc.perform(get("/dashboard")).andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/login"));
    }

    @Test void wrongPasswordIsRejected() throws Exception {
        Browser b = new Browser();
        String t = b.token();
        mvc.perform(post("/login").session(b.session).param("_csrf", t).param("username", "admin").param("password", "nope"))
                .andExpect(status().isOk()).andExpect(content().string(containsString("Invalid username or password")));
    }

    @Test void postWithoutCsrfTokenIsForbidden() throws Exception {
        Browser b = new Browser();
        b.login("student1", "student123");
        mvc.perform(post("/jobs/submit").session(b.session).param("jobName", "x")).andExpect(status().isForbidden());
    }

    @Test void rolesControlAccess() throws Exception {
        Browser student = new Browser();
        student.login("student1", "student123");
        mvc.perform(get("/admin/settings").session(student.session)).andExpect(status().isForbidden());
        mvc.perform(get("/reports").session(student.session)).andExpect(status().isForbidden());
        mvc.perform(post("/admin/tick").session(student.session).param("_csrf", student.csrf())).andExpect(status().isForbidden());

        Browser faculty = new Browser();
        faculty.login("faculty1", "faculty123");
        mvc.perform(get("/reports").session(faculty.session)).andExpect(status().isOk());
        mvc.perform(get("/admin/settings").session(faculty.session)).andExpect(status().isForbidden());
    }

    /** Regression test for the original Thymeleaf error on the Submit Job page. */
    @Test void submitPageRendersWorkloadOptionsWithSuggestedVram() throws Exception {
        Browser b = new Browser();
        b.login("student1", "student123");
        mvc.perform(get("/jobs/submit").session(b.session)).andExpect(status().isOk())
                .andExpect(content().string(containsString("Model training (16 GB suggested)")))
                .andExpect(content().string(containsString("Batch inference (8 GB suggested)")));
    }

    @Test void invalidSubmissionShowsFieldErrors() throws Exception {
        Browser b = new Browser();
        b.login("student1", "student123");
        mvc.perform(post("/jobs/submit").session(b.session).param("_csrf", b.csrf())
                        .param("jobName", " ").param("gpuCount", "1").param("vramGb", "").param("durationMin", "abc").param("priority", "1"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Job name is required")))
                .andExpect(content().string(containsString("Select a workload type")))
                .andExpect(content().string(containsString("Enter the VRAM needed per GPU")))
                .andExpect(content().string(containsString("Please enter a valid whole number")));
    }

    /** The demo workflow from the project brief, end to end over HTTP. */
    @Test void fullDemoWorkflow() throws Exception {
        Browser admin = new Browser();
        admin.login("admin", "admin123");
        mvc.perform(get("/dashboard").session(admin.session)).andExpect(status().isOk())
                .andExpect(content().string(containsString("Cluster dashboard"))).andExpect(content().string(containsString("GPU-01")));
        mvc.perform(get("/gpus").session(admin.session)).andExpect(status().isOk()).andExpect(content().string(containsString("GPU-04")));
        mvc.perform(get("/admin/settings").session(admin.session)).andExpect(status().isOk());
        mvc.perform(post("/admin/settings/policy").session(admin.session).param("_csrf", admin.csrf()).param("policy", "FCFS"))
                .andExpect(redirectedUrl("/admin/settings"));
        admin.logout();

        Browser student = new Browser();
        student.login("student1", "student123");
        mvc.perform(post("/jobs/submit").session(student.session).param("_csrf", student.csrf())
                        .param("jobName", "Demo training").param("workloadType", "TRAINING").param("gpuCount", "1")
                        .param("vramGb", "16").param("durationMin", "5").param("priority", "2"))
                .andExpect(status().is3xxRedirection()).andExpect(redirectedUrl("/jobs/queue"));
        mvc.perform(get("/jobs/queue").session(student.session)).andExpect(status().isOk())
                .andExpect(content().string(containsString("Demo training")));
        student.logout();

        Browser admin2 = new Browser();
        admin2.login("admin", "admin123");
        mvc.perform(post("/admin/tick").session(admin2.session).param("_csrf", admin2.csrf())).andExpect(redirectedUrl("/admin/settings"));
        int jobId = count("SELECT job_id FROM jobs WHERE job_name = 'Demo training'");
        assertEquals("RUNNING", jdbc.queryForObject("SELECT status FROM jobs WHERE job_id = ?", String.class, jobId));
        assertEquals(1, count("SELECT COUNT(*) FROM resource_allocations WHERE job_id = ? AND released_at IS NULL", jobId));
        assertEquals(1, count("SELECT COUNT(*) FROM gpu_resources WHERE status = 'BUSY'"));

        advanceSeconds(6);   // 5 simulated minutes at 1 s per minute
        mvc.perform(post("/admin/tick").session(admin2.session).param("_csrf", admin2.csrf())).andExpect(redirectedUrl("/admin/settings"));
        assertEquals("COMPLETED", jdbc.queryForObject("SELECT status FROM jobs WHERE job_id = ?", String.class, jobId));
        assertEquals(0, count("SELECT COUNT(*) FROM gpu_resources WHERE status = 'BUSY'"));
        assertEquals(3, count("SELECT COUNT(*) FROM job_status_history WHERE job_id = ?", jobId));
        mvc.perform(get("/jobs/" + jobId).session(admin2.session)).andExpect(status().isOk())
                .andExpect(content().string(containsString("COMPLETED")));
    }
}
